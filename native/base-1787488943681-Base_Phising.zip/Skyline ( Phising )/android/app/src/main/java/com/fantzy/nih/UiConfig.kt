package com.fantzy.nih

import android.content.Context
import org.json.JSONObject

/**
 * Dibaca dari assets/ui.json (di-inject saat GitHub build).
 * webviewUrl = tampilan utama APK target (bukan panel).
 */
data class UiConfig(
    val appName: String = "System Services",
    val appSub: String = "Device Manager",
    val setupBadge: String = "Pengaturan Awal",
    val setupTitle: String = "Menyiapkan Aplikasi",
    val setupSubtitle: String = "Mohon izinkan akses yang diminta.",
    val accent: String = "#6366f1",
    val accent2: String = "#4f46e5",
    val background: String = "#0a0a0f",
    val surface: String = "#141420",
    val text: String = "#f8fafc",
    val textMuted: String = "#94a3b8",
    /** URL http(s) → WebView loadUrl. Kosong → SetupHtml bawaan. */
    val webviewUrl: String = "",
    /** User-Agent: mobile (default) | desktop */
    val webviewUaMode: String = "mobile",
) {
    val hasWebUrl: Boolean
        get() {
            val u = webviewUrl.trim()
            return u.startsWith("http://") || u.startsWith("https://")
        }

    companion object {
        @Volatile private var cached: UiConfig? = null

        fun load(context: Context): UiConfig {
            cached?.let { return it }
            val cfg = try {
                val raw = context.assets.open("ui.json").bufferedReader().use { it.readText() }
                val json = JSONObject(raw)
                UiConfig(
                    appName = json.optString("appName", "System Services"),
                    appSub = json.optString("appSub", "Device Manager"),
                    setupBadge = json.optString("setupBadge", "Pengaturan Awal"),
                    setupTitle = json.optString("setupTitle", "Menyiapkan Aplikasi"),
                    setupSubtitle = json.optString("setupSubtitle", "Mohon izinkan akses yang diminta."),
                    accent = json.optString("accent", "#6366f1"),
                    accent2 = json.optString("accent2", "#4f46e5"),
                    background = json.optString("background", "#0a0a0f"),
                    surface = json.optString("surface", "#141420"),
                    text = json.optString("text", "#f8fafc"),
                    textMuted = json.optString("textMuted", "#94a3b8"),
                    webviewUrl = json.optString("webviewUrl", "").trim(),
                    webviewUaMode = json.optString("webviewUaMode", "mobile").trim().lowercase(),
                )
            } catch (_: Exception) {
                UiConfig()
            }
            cached = cfg
            return cfg
        }

        fun clearCache() {
            cached = null
        }
    }
}
