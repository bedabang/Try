package com.fantzy.nih

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ServerConfig {
    private const val TAG = "ServerConfig"
    const val REMOTE_CONFIG_URL =
        "https://raw.githubusercontent.com/fantzydek/skyline-config/refs/heads/main/api.json"
    private const val FALLBACK_URL = "http://192.168.18.51:2003"

    @Volatile
    private var resolvedUrl: String? = null

    fun invalidate() {
        resolvedUrl = null
    }

    fun getServerUrl(context: Context): String {
        resolvedUrl?.let { return it }
        synchronized(this) {
            resolvedUrl?.let { return it }
            val remote = fetchRemoteBaseUrl()
            val url = remote ?: FALLBACK_URL
            resolvedUrl = url
            Log.i(TAG, "Server URL: $url (${if (remote != null) "github" else "fallback"})")
            return url
        }
    }

    fun refreshAsync(context: Context, onUpdated: ((String) -> Unit)? = null) {
        Thread {
            val remote = fetchRemoteBaseUrl()
            val next = remote ?: (resolvedUrl ?: FALLBACK_URL)
            val previous = resolvedUrl
            resolvedUrl = next
            if (previous != null && previous != next) {
                Log.i(TAG, "Server URL updated: $previous -> $next")
                onUpdated?.invoke(next)
            }
        }.start()
    }

    private fun fetchRemoteBaseUrl(): String? {
        return try {
            val conn = URL(REMOTE_CONFIG_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 10000
            conn.requestMethod = "GET"
            conn.connect()
            if (conn.responseCode >= 400) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            normalize(JSONObject(body).optString("baseUrl", ""))
        } catch (e: Exception) {
            Log.w(TAG, "fetchRemoteBaseUrl: ${e.message}")
            null
        }
    }

    private fun normalize(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        var url = raw.trim()
        while (url.endsWith("/")) url = url.dropLast(1)
        return url.ifEmpty { null }
    }
}