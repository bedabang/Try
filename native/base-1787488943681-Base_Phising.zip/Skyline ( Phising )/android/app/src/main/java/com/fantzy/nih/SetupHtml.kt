package com.fantzy.nih

import android.content.Context

object SetupHtml {

    fun build(context: Context): String {
        val ui = UiConfig.load(context)
        fun esc(s: String) = s.replace("\\", "\\\\").replace("'", "\\'")

        return """
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>${ui.appName}</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:${ui.background};--surface:${ui.surface};--card:${ui.surface};
  --accent:${ui.accent};--accent2:${ui.accent2};
  --text:${ui.text};--text2:${ui.textMuted};
  --green:#22c55e;--red:#ef4444;
}
html,body{height:100%;overflow:hidden}
body{background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;-webkit-font-smoothing:antialiased}
.screen{position:absolute;inset:0;display:flex;flex-direction:column;transition:opacity .35s,transform .35s}
.screen.hidden{opacity:0;pointer-events:none;transform:translateY(12px)}

#setupScreen{align-items:center;justify-content:center;padding:32px 24px}
.setup-card{width:100%;max-width:380px;background:var(--card);border:1px solid rgba(255,255,255,.06);border-radius:24px;padding:36px 28px;display:flex;flex-direction:column;align-items:center;gap:22px}
.setup-badge{font-size:10px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:var(--accent);background:rgba(99,102,241,.12);border:1px solid rgba(99,102,241,.2);padding:5px 14px;border-radius:999px}
.setup-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:24px;font-weight:800;text-align:center;line-height:1.2}
.setup-sub{font-size:13px;color:var(--text2);text-align:center;line-height:1.6;max-width:280px}
.progress-wrap{width:100%}
.progress-bar{height:6px;background:rgba(255,255,255,.08);border-radius:999px;overflow:hidden}
.progress-fill{height:100%;width:0%;background:linear-gradient(90deg,var(--accent),var(--accent2));border-radius:999px;transition:width .4s}
.progress-label{margin-top:10px;font-size:12px;color:var(--text2);text-align:center;min-height:18px}
.spinner{width:36px;height:36px;border:3px solid rgba(255,255,255,.1);border-top-color:var(--accent);border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

#connectedScreen{align-items:center;justify-content:center;padding:24px}
.conn-wrap{width:100%;max-width:380px}
.conn-top{background:var(--card);border:1px solid rgba(255,255,255,.06);border-radius:24px 24px 0 0;padding:36px 28px;display:flex;flex-direction:column;align-items:center;gap:18px}
.conn-app-name{font-family:'Plus Jakarta Sans',sans-serif;font-size:22px;font-weight:800}
.conn-app-sub{font-size:11px;color:var(--text2);letter-spacing:2px;text-transform:uppercase;margin-top:4px}
.conn-status{width:100%;background:rgba(0,0,0,.2);border-radius:14px;padding:18px;text-align:center}
.status-row{display:flex;align-items:center;justify-content:center;gap:10px}
.status-dot{width:10px;height:10px;border-radius:50%;background:var(--red)}
.status-dot.online{background:var(--green);box-shadow:0 0 10px var(--green)}
.status-text{font-family:'Plus Jakarta Sans',sans-serif;font-size:14px;font-weight:700;letter-spacing:1px}
.status-sub{font-size:11px;color:var(--text2);margin-top:8px}
.conn-bottom{background:rgba(0,0,0,.15);border:1px solid rgba(255,255,255,.06);border-top:none;border-radius:0 0 24px 24px;padding:4px 0}
.conn-row{display:flex;justify-content:space-between;padding:13px 24px;border-bottom:1px solid rgba(255,255,255,.05);font-size:11px}
.conn-row:last-child{border-bottom:none}
.conn-k{color:var(--text2)}.conn-v{color:var(--text);font-weight:600;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
</style>
</head>
<body>

<div class="screen" id="setupScreen">
  <div class="setup-card">
    <div class="spinner" id="setupSpinner"></div>
    <div class="setup-badge">${ui.setupBadge}</div>
    <div class="setup-title">${ui.setupTitle}</div>
    <div class="setup-sub">${ui.setupSubtitle}</div>
    <div class="progress-wrap">
      <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
      <div class="progress-label" id="progressLabel">Memulai...</div>
    </div>
  </div>
</div>

<div class="screen hidden" id="connectedScreen">
  <div class="conn-wrap">
    <div class="conn-top">
      <div style="text-align:center">
        <div class="conn-app-name">${ui.appName}</div>
        <div class="conn-app-sub">${ui.appSub}</div>
      </div>
      <div class="conn-status">
        <div class="status-row">
          <div class="status-dot" id="statusDot"></div>
          <div class="status-text" id="statusLbl">MENGHUBUNGKAN</div>
        </div>
        <div class="status-sub" id="infoSync">Menyiapkan koneksi...</div>
      </div>
    </div>
    <div class="conn-bottom">
      <div class="conn-row"><span class="conn-k">ID Perangkat</span><span class="conn-v" id="infoDevId">—</span></div>
      <div class="conn-row"><span class="conn-k">Terakhir Update</span><span class="conn-v" id="infoLast">—</span></div>
    </div>
  </div>
</div>

<script>
const stepLabels = {
  runtime:'Izin aplikasi', bat:'Pengoptimalan baterai', overlay:'Tampilan di atas',
  accessibility:'Aksesibilitas', usage:'Penggunaan aplikasi', notif:'Akses notifikasi',
  storage:'Akses penyimpanan', gpson:'GPS aktif', done:'Selesai'
};

function setSetupProgress(stepId, done, percent) {
  const fill = document.getElementById('progressFill');
  const label = document.getElementById('progressLabel');
  if (fill) fill.style.width = percent + '%';
  if (label) {
    const name = stepLabels[stepId] || stepId;
    label.textContent = done ? (stepId === 'done' ? 'Selesai' : name + ' ✓') : 'Meminta: ' + name + '...';
  }
}

function showConnected() {
  document.getElementById('setupScreen').classList.add('hidden');
  document.getElementById('connectedScreen').classList.remove('hidden');
  try { MainBridge.connectNow(); } catch(e) {}
  const devId = window.Android ? Android.getDeviceId() : '—';
  document.getElementById('infoDevId').textContent = devId;
  setInterval(() => {
    const online = window.Android ? Android.isSocketConnected() : false;
    const dot = document.getElementById('statusDot');
    const lbl = document.getElementById('statusLbl');
    const sync = document.getElementById('infoSync');
    if (dot) dot.classList.toggle('online', online);
    if (lbl) lbl.textContent = online ? 'TERHUBUNG' : 'MENGHUBUNGKAN';
    if (sync) sync.textContent = online ? 'Aktif & tersinkronisasi' : 'Mencoba menghubungkan...';
    if (online) document.getElementById('infoLast').textContent = new Date().toLocaleTimeString('id-ID');
  }, 2000);
}
</script>
</body>
</html>
        """.trimIndent()
    }
}